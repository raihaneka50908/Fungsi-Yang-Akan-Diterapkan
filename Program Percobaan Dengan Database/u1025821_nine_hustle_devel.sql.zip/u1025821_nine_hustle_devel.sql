-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 04, 2023 at 01:56 AM
-- Server version: 10.5.20-MariaDB-cll-lve
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u1025821_nine_hustle_devel`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` char(36) NOT NULL,
  `addressable_id` char(36) NOT NULL,
  `addressable_type` varchar(255) NOT NULL,
  `longitude` decimal(10,8) NOT NULL,
  `latitude` decimal(11,8) NOT NULL,
  `country` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `addressable_id`, `addressable_type`, `longitude`, `latitude`, `country`, `province`, `city`, `street`, `note`, `created_at`, `updated_at`) VALUES
('994cbf19-e379-47a6-ba6e-202ddd017fb1', '039ab639-8203-4535-9f36-2de646b06f4d', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e54e-4c90-8b99-55d450ebfcc2', '12109cd7-0891-46bf-8970-7d18565affd7', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bekasi', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e5a4-4a3f-a502-7ee75196fa6a', '174dd17b-01c9-430b-8307-0090384cbe32', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e5f9-4cf0-96c5-956af21b0f5e', '189596a1-ad7b-459b-8d06-428fe775cd07', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e64c-4f2e-8883-8c9794c32ae5', '28932168-9ce5-4b95-ae0f-14a65f20e058', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e698-455f-a05c-985e049e8a9d', '49af54cb-82da-4dff-8363-e8dc02a29f1c', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Jakarta', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e6e3-4e68-86e5-00f4c0fef87e', '4e735530-c52a-4132-a12c-c93a439ac18b', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e731-410a-95ff-4f947201f355', '51ecc6cd-b4fd-463b-ae0f-42578e4741fd', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bekasi', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e788-4a10-a6e5-1095fa8cc091', '945b10dd-9d9b-424f-8ec8-3d16ced514ca', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Jakarta', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e7d2-46e0-9ac3-0ef54728533e', '9dc41559-0a46-4ffe-b6f5-afe9fe1aa0a3', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bekasi', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e818-46ac-93c2-f16cbe8c2085', 'a3f53d63-98d9-437b-a277-b495e1c94baf', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Jakarta', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e85a-4a9f-9401-a3472ccdc4bf', 'c3c9fc7a-8ef9-44a4-9a93-080b6d948e91', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e8a7-4575-bce5-d8a306cc6b67', 'c439c6ed-5171-42cd-9d1e-165bc0ae2b87', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Jakarta', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e8eb-4992-be4e-b824929337cf', 'c9e9da85-43d6-4bbd-a7aa-22baeff56a2d', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e926-430e-8dda-d0ed3c98bddf', 'ce59d42f-00f2-424e-818b-4cb885100b4c', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bekasi', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-e963-4f89-ada0-01a8f7a7494a', 'de98298c-6a0b-4cf4-8fd4-07cd8c32ab2f', 'App\\Models\\Gigs\\Gig', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bekasi', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ad9f-4184-935d-b872894a7e5c', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'App\\Models\\Studios\\Studio', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-b2a3-4ae9-aa69-767b3cbe0af9', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'App\\Models\\Studios\\Studio', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bekasi', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-bc5d-4060-a3f4-70a12c3b1dae', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'App\\Models\\Studios\\Studio', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Jakarta', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1f-24f2-4333-bd55-bf2602eb75d1', '994cbf1f-2419-4ffe-a8cd-212bf33a338a', 'App\\Models\\Studios\\Studio', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-2603-4ab1-8db7-214e45068fd2', '994cbf1f-253c-485b-b4ae-4cd0291bdf18', 'App\\Models\\Studios\\Studio', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bekasi', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-2764-4428-bc50-1597ccaeb398', '994cbf1f-2647-4340-a04e-74fbeb797682', 'App\\Models\\Studios\\Studio', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Jakarta', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-2922-4885-acb5-3d66e505b50c', '994cbf1f-27ef-4133-a8bc-57e0160cbae2', 'App\\Models\\Studios\\Studio', 41.40338000, 2.17403000, 'Indonesia', 'Kaltim', 'Bogor', 'wqeqweqwe', 'wqeqwewqe', '2023-05-31 16:03:50', '2023-05-31 16:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` char(36) NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `banner_category_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `image`, `url`, `banner_category_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
('6c8fa596-f47f-4175-8150-df64ff4be686', '/storage/banners/yxGepJuXLBNmg46qFQbMn98eZ1IGlstzp8QrdWFO.jpg', 'https://www.google.com', '4c46ea44-d728-426b-a398-e8bcc41f632c', '2023-06-02 14:25:20', '2023-06-02 14:25:20', NULL),
('df41f6f8-2c4c-49d3-919a-f9ea8e674fc8', '/storage/banners/oFa03Zg5JcJGkNl1lDzeKjs4WksWHZzyyRhSowlj.jpg', 'https://www.google.com', '4c46ea44-d728-426b-a398-e8bcc41f632c', '2023-06-02 14:51:53', '2023-06-02 14:51:53', NULL),
('fc5288a4-f567-4934-88da-5fe4f61a4335', '/storage/banners/yxGepJuXLBNmg46qFQbMn98eZ1IGlstzp8QrdWFO.jpg', 'https://www.google.com', '4c46ea44-d728-426b-a398-e8bcc41f632c', '2023-06-02 14:40:54', '2023-06-02 14:40:54', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `banner_categories`
--

CREATE TABLE `banner_categories` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banner_categories`
--

INSERT INTO `banner_categories` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
('4c46ea44-d728-426b-a398-e8bcc41f632c', 'Desain', '2023-06-02 12:45:38', '2023-06-02 12:45:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `base_studio_schedules`
--

CREATE TABLE `base_studio_schedules` (
  `id` char(36) NOT NULL,
  `studio_id` char(36) NOT NULL,
  `monday` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`monday`)),
  `tuesday` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tuesday`)),
  `wednesday` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`wednesday`)),
  `thursday` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`thursday`)),
  `friday` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`friday`)),
  `saturday` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`saturday`)),
  `sunday` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sunday`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `base_studio_schedules`
--

INSERT INTO `base_studio_schedules` (`id`, `studio_id`, `monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`, `created_at`, `updated_at`) VALUES
('994cbf19-ec4c-4bda-9921-88369d6abb3c', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ae38-4e87-ae0d-14281877d7c3', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-b365-4ecb-b216-2b68f6f20a8f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-bd71-4572-b69a-19c528aeac91', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1e-17fa-407b-94ce-cf8fc26d1dad', '994cbf1e-1792-4dac-b40d-d163f99d76b9', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1f-2493-4839-8adb-cc898bfcc996', '994cbf1f-2419-4ffe-a8cd-212bf33a338a', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-25b0-40e3-b149-558efab01d62', '994cbf1f-253c-485b-b4ae-4cd0291bdf18', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '[[\"08:00\",\"10:00\"],[\"10:01\",\"12:00\"],[\"13:00\",\"15:00\"],[\"15:01\",\"18:00\"]]', '2023-05-31 16:03:50', '2023-05-31 16:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
('1165a9da-1fc2-4dd5-ba2e-363a6e63455e', 'editing', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('2a50571d-9c5f-4f8d-b119-9fcf46c55837', 'programming', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'photography', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('66a235d8-f0a7-4ed5-9218-0367bd17f214', 'copywriting', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('a5735b5d-c916-47ba-92ef-48a4c7bc2626', 'design', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `device_tokens`
--

CREATE TABLE `device_tokens` (
  `id` char(36) NOT NULL,
  `token` varchar(255) NOT NULL,
  `user_id` char(36) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_subscriptions`
--

CREATE TABLE `email_subscriptions` (
  `id` char(36) NOT NULL,
  `email` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `freelancers`
--

CREATE TABLE `freelancers` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `freelancers`
--

INSERT INTO `freelancers` (`id`, `user_id`, `created_at`, `updated_at`) VALUES
('994cbef7-3384-49bb-aba6-b77d7f1b4653', '994cbef7-327c-48a9-be42-6e07b4733815', '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-5592-4c93-8008-983a581bb837', '994cbef7-5488-43f6-b184-f933a6a796f8', '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-7711-4d90-b87b-97c1a1344ccf', '994cbef7-7618-43b1-b421-1f63392aaffb', '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', '994cbef7-98e3-452c-b989-aa38524fbb2b', '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-bc82-4e7d-aa08-8f6304193df0', '994cbef7-bb8a-4a20-a6af-e28d782e17c8', '2023-05-31 16:03:24', '2023-05-31 16:03:24');

-- --------------------------------------------------------

--
-- Table structure for table `gigs`
--

CREATE TABLE `gigs` (
  `id` char(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `user_id` char(36) NOT NULL,
  `description` text NOT NULL,
  `category_id` char(36) NOT NULL,
  `subcategory_id` char(36) NOT NULL,
  `is_allowed` timestamp NULL DEFAULT NULL,
  `is_recommended` tinyint(1) NOT NULL DEFAULT 0,
  `is_explorable` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gigs`
--

INSERT INTO `gigs` (`id`, `title`, `slug`, `user_id`, `description`, `category_id`, `subcategory_id`, `is_allowed`, `is_recommended`, `is_explorable`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
('039ab639-8203-4535-9f36-2de646b06f4d', 'gigs studio no address 2', 'gigs-studio-no-address2-photography-studio-tests-PUtG3pySsYmMnwCf8SCuYcGuTqhKbq2t', '994cbef7-327c-48a9-be42-6e07b4733815', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', NULL, 0, 0, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('12109cd7-0891-46bf-8970-7d18565affd7', 'gigs no studio 2', 'gigs-no-studio2-photography-studio-tests-BbtkdRiYIEnUzv1MmcsvPxJ1vogRtUNr', '994cbef7-1344-463c-a9f2-b10f438fab9a', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '2023-06-07 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('174dd17b-01c9-430b-8307-0090384cbe32', 'gigs studio event 2', 'gigs-studio-event2-photography-studio-tests-pDRdxdK1CtKpfHyFEbFDsCssF0o4sZ4a', '994cbef6-bff5-479f-a695-0efbe35251c6', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '2023-06-21 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('189596a1-ad7b-459b-8d06-428fe775cd07', 'gigs studio no event 2', 'gigs-studio-no-event2-photography-studio-tests-xDEfCJAIm9vxCiwiG8a5FcUkLDp9aZkb', '994cbef7-5488-43f6-b184-f933a6a796f8', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '2023-06-14 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('28932168-9ce5-4b95-ae0f-14a65f20e058', 'gigs studio no schedule 1', 'gigs-studio-no-schedule1-photography-studio-tests-7oqr5ijWwAyNBHT2JmG7wpAnkHb0nHqA', '994cbef6-dbfa-4c64-92ac-645e3ba775e1', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '2023-06-20 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('34115155-ffcd-410d-b786-9083953b7f20', 'Test photography wedding 2', 'test-photography-wedding2-copywriting-web-F43zgk9uvZz3QkaQ2IYtQ46cmcjVxAEL', '994cbef7-327c-48a9-be42-6e07b4733815', 'lorem ipsum ini deskripsi ya ampun.', '66a235d8-f0a7-4ed5-9218-0367bd17f214', '05b6fb88-3fad-4d44-aa33-e2b6c477adec', NULL, 0, 0, 1, '2023-05-31 16:50:05', '2023-05-31 16:50:05', NULL),
('49af54cb-82da-4dff-8363-e8dc02a29f1c', 'gigs studio event 1', 'gigs-studio-event1-photography-studio-tests-Gk1OTi7y6nqSja4MpdRaeyE0hfQh3Pgm', '994cbef6-dbfa-4c64-92ac-645e3ba775e1', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '2023-06-20 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('4e735530-c52a-4132-a12c-c93a439ac18b', 'prewed premium', 'prewed-premium-photography-wedding-tblXmm8nzrPQi9TxnsfP1QiG6cYqNfq3', '994cbef6-dbfa-4c64-92ac-645e3ba775e1', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'fa0759b1-6443-47a5-a6a0-d9ff5cb8d1d5', '2023-06-12 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('51ecc6cd-b4fd-463b-ae0f-42578e4741fd', 'gigs studio event 3', 'gigs-studio-event3-photography-studio-tests-rAb7wtUPGxculc83C5d9mYrfADXfpjED', '994cbef6-f795-4f3c-85b3-21c257867049', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '2023-06-12 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('69d2de43-50d2-4efd-ad96-8de85403e1ca', 'Test photography wedding 1', 'test-photography-wedding1-copywriting-web-IH6ZwmncnQDQhOviAQiLBT0PFmPl52gY', '994cbef7-327c-48a9-be42-6e07b4733815', 'lorem ipsum ini deskripsi ya ampun.', '66a235d8-f0a7-4ed5-9218-0367bd17f214', '05b6fb88-3fad-4d44-aa33-e2b6c477adec', NULL, 0, 0, 1, '2023-05-31 16:49:02', '2023-05-31 16:49:02', NULL),
('7072975e-7403-428c-80f2-1a9098ce2412', 'Test photography wedding 2', 'test-photography-wedding2-photography-sports-g6wNyyqWdCbjvqnqFiIDvRUuPeGuViii', '994cbef7-327c-48a9-be42-6e07b4733815', 'lorem ipsum ini deskripsi ya ampun.', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '9592de16-ebc5-4c5c-b36b-5a10e9082ae3', NULL, 0, 0, 1, '2023-06-03 17:55:35', '2023-06-03 17:55:35', NULL),
('85a81312-43a2-4fca-ab56-5c344a555b7e', 'buat film', 'buat-film-editing-video-editing-XBRvWkiqKKdynSA79ZXOpObRzm9MDpZg', '994cbef6-bff5-479f-a695-0efbe35251c6', 'desc', '1165a9da-1fc2-4dd5-ba2e-363a6e63455e', '15de4f72-8e6f-4ed2-bb21-37140ab1e777', '2023-06-13 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('892495bc-8886-4b38-a270-83611e892981', 'buat blog murah', 'buat-blog-murah-copywriting-blogposts-sdKqCfeZAstgXSvLyefE5pFoI2U3U7Mx', '994cbef7-bb8a-4a20-a6af-e28d782e17c8', 'desc', '66a235d8-f0a7-4ed5-9218-0367bd17f214', '5820c9c8-c246-4ec3-9ed0-987fd6796dbe', NULL, 0, 0, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('92cce5f7-f2bc-447a-bcc4-f72a75a3557b', 'buat poster mahal', 'buat-poster-mahal-design-poster-design-ejMwqZchI78AWsj7YBmlSnhwfdpPjw5H', '994cbef7-1344-463c-a9f2-b10f438fab9a', 'desc', 'a5735b5d-c916-47ba-92ef-48a4c7bc2626', 'c687640f-0ce1-4c53-82c1-75189991c679', '2023-06-16 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('945b10dd-9d9b-424f-8ec8-3d16ced514ca', 'gigs studio no address 1', 'gigs-studio-no-address1-photography-studio-tests-xzLJSPo4I4JFq2tGBrtxGG0ffkacmmAE', '994cbef6-dbfa-4c64-92ac-645e3ba775e1', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', NULL, 0, 0, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('9613f62c-1a64-4a1c-99fa-179568c7b929', 'static web development', 'static-web-development-programming-web-development-OAk0q1ppuEQFeTKJkSKPjoZHfhdZQOrB', '994cbef7-7618-43b1-b421-1f63392aaffb', 'desc', '2a50571d-9c5f-4f8d-b119-9fcf46c55837', 'ffb0f2ec-965f-443b-aecd-e6ead7512c07', NULL, 0, 0, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('9dc41559-0a46-4ffe-b6f5-afe9fe1aa0a3', 'gigs studio no event 1', 'gigs-studio-no-event1-photography-studio-tests-r2u46BKxnMuJPJp0OrkM1YKtH3aSn7HF', '994cbef7-7618-43b1-b421-1f63392aaffb', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '2023-06-11 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('a344db0a-857a-4ac9-994b-cfb462197b2b', 'buat banner murah', 'buat-banner-murah-design-banner-design-4aIl6FI63X4kyC57IERqR0Ia4aAdhsqy', '994cbef7-98e3-452c-b989-aa38524fbb2b', 'desc', 'a5735b5d-c916-47ba-92ef-48a4c7bc2626', 'e7ef34ab-8ef7-4b1a-b1c1-8e08a8155e80', '2023-06-12 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('a3f53d63-98d9-437b-a277-b495e1c94baf', 'prewed new', 'prewed-new-photography-wedding-wll2rtC16cxvp3zyJBJBavryQZ6ZhzAP', '994cbef6-dbfa-4c64-92ac-645e3ba775e1', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'fa0759b1-6443-47a5-a6a0-d9ff5cb8d1d5', '2023-06-13 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('b45d9d9e-0c98-4cd2-b125-8b30991b7e12', 'web development murah', 'web-development-murah-programming-web-development-H8VsIyAXTIKjXpLakkFqyAgK1OS7CkcF', '994cbef7-bb8a-4a20-a6af-e28d782e17c8', 'desc', '2a50571d-9c5f-4f8d-b119-9fcf46c55837', 'ffb0f2ec-965f-443b-aecd-e6ead7512c07', NULL, 0, 0, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('b5901174-26ff-4f68-af87-13419cc2cf11', 'buat blog bahasa inggris', 'buat-blog-bahasa-inggris-copywriting-blogposts-38uGITiyyM2fJxTD7G1IxdmNPPMJiPEf', '994cbef6-f795-4f3c-85b3-21c257867049', 'desc', '66a235d8-f0a7-4ed5-9218-0367bd17f214', '5820c9c8-c246-4ec3-9ed0-987fd6796dbe', '2023-06-11 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('c3c9fc7a-8ef9-44a4-9a93-080b6d948e91', 'gigs studio no schedule 2', 'gigs-studio-no-schedule2-photography-studio-tests-zgE1moVOsJtTJlKEt5Ud6FKDabputhG1', '994cbef7-1344-463c-a9f2-b10f438fab9a', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '2023-06-21 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('c439c6ed-5171-42cd-9d1e-165bc0ae2b87', 'gigs no studio 1', 'gigs-no-studio1-photography-studio-tests-bujsNTzKVOLKCikbzxxTNDu2DEWqWGuV', '994cbef7-5488-43f6-b184-f933a6a796f8', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', '8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '2023-06-24 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('c9e9da85-43d6-4bbd-a7aa-22baeff56a2d', 'prewed city', 'prewed-city-photography-wedding-ZCAYrHiE8weZesIUWBOYkmqyQTyQecY2', '994cbef6-bff5-479f-a695-0efbe35251c6', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'fa0759b1-6443-47a5-a6a0-d9ff5cb8d1d5', '2023-06-17 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('ce59d42f-00f2-424e-818b-4cb885100b4c', 'prewed murah', 'prewed-murah-photography-wedding-eDhJNTZPCHS5eZxqda7fuoarscmsfWlI', '994cbef6-bff5-479f-a695-0efbe35251c6', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'fa0759b1-6443-47a5-a6a0-d9ff5cb8d1d5', '2023-06-12 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('cfdbb1df-68c9-47ed-922e-6a0fb38e32b8', 'buat poster murah', 'buat-poster-murah-design-poster-design-phXMO9koCBcihtz1fBUMg1Co0W1tGmN7', '994cbef6-dbfa-4c64-92ac-645e3ba775e1', 'desc', 'a5735b5d-c916-47ba-92ef-48a4c7bc2626', 'c687640f-0ce1-4c53-82c1-75189991c679', '2023-06-24 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('d11b1089-dd72-427b-861e-468e8ec626c1', 'prewed amateur', 'prewed-amateur-photography-wedding-UaNCRPPU2EhG9yTc6tr5Z7Vgfo1oO2Sq', '994cbef7-7618-43b1-b421-1f63392aaffb', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'fa0759b1-6443-47a5-a6a0-d9ff5cb8d1d5', '2023-06-14 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('de98298c-6a0b-4cf4-8fd4-07cd8c32ab2f', 'prewed street', 'prewed-street-photography-wedding-yRVHQxoA882eCdTo01KPRiwB1Z9lEprG', '994cbef7-327c-48a9-be42-6e07b4733815', 'desc', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'fa0759b1-6443-47a5-a6a0-d9ff5cb8d1d5', '2023-06-15 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('e8e28440-8dc6-495c-9c08-a0b45d4bc008', 'video editing murah', 'video-editing-murah-editing-video-editing-sphW3RrntCzgdSDyLUBQS2kk5PqaDPRP', '994cbef6-bff5-479f-a695-0efbe35251c6', 'desc', '1165a9da-1fc2-4dd5-ba2e-363a6e63455e', '15de4f72-8e6f-4ed2-bb21-37140ab1e777', NULL, 0, 0, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('f1421951-1257-4d9d-be4a-f52daca85cf5', 'buat banner mahal', 'buat-banner-mahal-design-banner-design-6wabWkQaQ6BpXQdFIPuXF0KQYq5q0UR1', '994cbef7-1344-463c-a9f2-b10f438fab9a', 'desc', 'a5735b5d-c916-47ba-92ef-48a4c7bc2626', 'e7ef34ab-8ef7-4b1a-b1c1-8e08a8155e80', '2023-06-12 16:03:41', 0, 1, 1, '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gig_images`
--

CREATE TABLE `gig_images` (
  `id` char(36) NOT NULL,
  `image` varchar(255) NOT NULL,
  `gig_id` char(36) NOT NULL,
  `is_thumbnail` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gig_images`
--

INSERT INTO `gig_images` (`id`, `image`, `gig_id`, `is_thumbnail`, `deleted_at`, `created_at`, `updated_at`) VALUES
('00b22023-dd7a-4c37-8715-8e12b335d2ff', 'sNDf9mXv5KSmCgxMStVKSQYQFrMwyDTW.jpg', 'c3c9fc7a-8ef9-44a4-9a93-080b6d948e91', 1, NULL, '2023-05-31 16:03:45', '2023-05-31 16:03:45'),
('07038e3f-7cac-477f-8a9b-527182be6ef1', 'ogZ1Fi687m0Ykol0379L8jLN0yW8WO8R.jpg', 'ce59d42f-00f2-424e-818b-4cb885100b4c', 0, NULL, '2023-05-31 16:03:42', '2023-05-31 16:03:42'),
('126eebf7-0bf2-481a-b587-56c62f1f113d', 'qD6kXW1ZvrRyH5S5KkVv1pKSZiuAYTJ8.jpg', 'cfdbb1df-68c9-47ed-922e-6a0fb38e32b8', 0, NULL, '2023-05-31 16:03:41', '2023-05-31 16:03:41'),
('1343bb5c-866f-4d4e-8b6f-267472e4f8c0', 'QefT8bdQxtcUuB5EbdOSjINjbW6xYPpC.jpg', 'c439c6ed-5171-42cd-9d1e-165bc0ae2b87', 1, NULL, '2023-05-31 16:03:44', '2023-05-31 16:03:44'),
('16d0df65-0ac9-4292-b041-e15b8185a1ec', 'as5xzBk9RCjTJ4xg2F2PMmbKslJk3UJh.jpg', '28932168-9ce5-4b95-ae0f-14a65f20e058', 0, NULL, '2023-05-31 16:03:45', '2023-05-31 16:03:45'),
('2068fe6e-ad45-40f9-bfed-61c46cc28c95', 'TLTDHpPhPDwMZM2e3xNt4ueM2A95B9Cs.jpg', 'd11b1089-dd72-427b-861e-468e8ec626c1', 0, NULL, '2023-05-31 16:03:43', '2023-05-31 16:03:43'),
('25bfec3d-65e6-4a90-b5fc-862f606ca2b8', 'Fk8r1DqyYoIGkw0N5lCqK2uGIjMNbT47.jpg', '9dc41559-0a46-4ffe-b6f5-afe9fe1aa0a3', 0, NULL, '2023-05-31 16:03:45', '2023-05-31 16:03:45'),
('270baf8a-1fae-42fe-ae76-3d4fa0275576', 'diSOHJfQZ39jGN5Ex9QbjjydE0mwfCdL.jpg', '12109cd7-0891-46bf-8970-7d18565affd7', 1, NULL, '2023-05-31 16:03:45', '2023-05-31 16:03:45'),
('2f4cf0e3-aedd-4d1c-8cf3-4d298a19b095', 'QAWVK7z2cSgg6KRjfINUAS9LTth0xAH5.jpg', '4e735530-c52a-4132-a12c-c93a439ac18b', 0, NULL, '2023-05-31 16:03:42', '2023-05-31 16:03:42'),
('3034a505-8898-43ca-bf46-7f5532e82ba0', 'j2hCck6Zm9iEePMjY3pUVvrzxBw9Gat4.jpg', '92cce5f7-f2bc-447a-bcc4-f72a75a3557b', 1, NULL, '2023-05-31 16:03:42', '2023-05-31 16:03:42'),
('39690925-ec5e-4787-8794-d33de952e11f', '0pgcrLNULeDf53VX4xkKfTThyhZ01L7E.jpg', 'ce59d42f-00f2-424e-818b-4cb885100b4c', 1, NULL, '2023-05-31 16:03:42', '2023-05-31 16:03:42'),
('4844e44b-da4d-41aa-bb66-8f901f6a396e', 'cRG4XOAWZ99NYAvIEKYfIck339iE64Br.jpg', 'c9e9da85-43d6-4bbd-a7aa-22baeff56a2d', 1, NULL, '2023-05-31 16:03:43', '2023-05-31 16:03:43'),
('54ef9ce1-3b1b-4445-aeb0-d417a63bd67e', 'Xo6nL67xBz9nVJXbHFqEGwwwZHa3RnEd.jpg', '85a81312-43a2-4fca-ab56-5c344a555b7e', 0, NULL, '2023-05-31 16:03:44', '2023-05-31 16:03:44'),
('59539dd7-9c53-4a6b-a071-a5adeaf6ed68', 'd6QUYg48gYxmXuEi5xJQnTHUWaSKpDff.jpg', 'b5901174-26ff-4f68-af87-13419cc2cf11', 0, NULL, '2023-05-31 16:03:44', '2023-05-31 16:03:44'),
('5c002fbd-2e67-4991-a4ad-e80cc0e7f6d4', '9PoNA8V7JPw83SCa28z5ghObgWBeGoAg.jpg', 'a3f53d63-98d9-437b-a277-b495e1c94baf', 0, NULL, '2023-05-31 16:03:44', '2023-05-31 16:03:44'),
('5c3f7d05-8c27-4a8d-9548-5592f29e47c2', 'uDCdZlsBYwNta6gZK5D1UmJdu23NMt0q.jpg', 'c3c9fc7a-8ef9-44a4-9a93-080b6d948e91', 0, NULL, '2023-05-31 16:03:45', '2023-05-31 16:03:45'),
('6089e2f6-0729-427a-b31b-d492d3de7c95', 'DhlEJh34SuYty2Icvg4ESqBQQdg7Wbna.jpg', '189596a1-ad7b-459b-8d06-428fe775cd07', 0, NULL, '2023-05-31 16:03:46', '2023-05-31 16:03:46'),
('6798e334-3571-4624-b59a-9cc2da99c392', '1gRnYR2DGzEhtrgSGvreo58ifsvlcfDX.jpg', 'a3f53d63-98d9-437b-a277-b495e1c94baf', 1, NULL, '2023-05-31 16:03:43', '2023-05-31 16:03:43'),
('727b589a-c25c-4562-a2f0-3fc37a6b2073', 'IT0g5PDwwQltu8fXayqho0o6HFPujKkq.jpg', '12109cd7-0891-46bf-8970-7d18565affd7', 0, NULL, '2023-05-31 16:03:45', '2023-05-31 16:03:45'),
('72a71faf-6ee7-4229-a098-0c86461160f9', 'h4cIH8glTPSvBafrqhEP0UE79k3fpDu7.jpg', '85a81312-43a2-4fca-ab56-5c344a555b7e', 1, NULL, '2023-05-31 16:03:44', '2023-05-31 16:03:44'),
('7cecb498-1eff-494a-89eb-c5eca7e4abfd', 'py5eJ8mYUROAjSDHRihVybE4r6Uvm1vs.jpg', 'c9e9da85-43d6-4bbd-a7aa-22baeff56a2d', 0, NULL, '2023-05-31 16:03:43', '2023-05-31 16:03:43'),
('863f9b9f-9a12-4514-88d4-3c6e523154ef', 'JJghNQb95hlwYGbNusjeWgzML4ij67MW.jpg', '92cce5f7-f2bc-447a-bcc4-f72a75a3557b', 0, NULL, '2023-05-31 16:03:42', '2023-05-31 16:03:42'),
('8e1df94f-03b2-46af-9885-4e6f876801c2', 'bB34Tw5JbkbSIUoQe6ZivnsplvFSzmKh.jpg', 'de98298c-6a0b-4cf4-8fd4-07cd8c32ab2f', 1, NULL, '2023-05-31 16:03:43', '2023-05-31 16:03:43'),
('8e2f22f4-ae63-4c80-841e-9cb872b765e8', 'd81dPKgs8lpHvENQJTOCvYCOGoKsGScF.jpg', '49af54cb-82da-4dff-8363-e8dc02a29f1c', 1, NULL, '2023-05-31 16:03:46', '2023-05-31 16:03:46'),
('9644a0ee-5622-49e1-bd11-79c2ab5fc366', 'gbI1ndvmcUl3lazFufkidWVykToVbKyX.jpg', '174dd17b-01c9-430b-8307-0090384cbe32', 0, NULL, '2023-05-31 16:03:46', '2023-05-31 16:03:46'),
('9bb99698-e10b-4b62-8bc2-0fe0c7276bf0', '5bCDhOPh9rA2APmvXCdhXDnjx9VwP0WD.jpg', 'a344db0a-857a-4ac9-994b-cfb462197b2b', 1, NULL, '2023-05-31 16:03:41', '2023-05-31 16:03:41'),
('a1a9270e-591b-4f32-ab41-248226bce037', 'Uyr8M2ZUqN4EOfxxYaw9lkIpzNemS3C6.jpg', 'de98298c-6a0b-4cf4-8fd4-07cd8c32ab2f', 0, NULL, '2023-05-31 16:03:43', '2023-05-31 16:03:43'),
('a51d41ac-a2e0-41e3-996d-96b8f208d9e0', 'gUIqXh2PSek1DZBb87qqq3fXdAqRDA69.jpg', 'a344db0a-857a-4ac9-994b-cfb462197b2b', 0, NULL, '2023-05-31 16:03:41', '2023-05-31 16:03:41'),
('a92a5563-22db-4bb8-9f59-272d7adbd570', '1kR6VJ8SNnTk0yDBefdpiikjTP7riQZt.jpg', 'f1421951-1257-4d9d-be4a-f52daca85cf5', 1, NULL, '2023-05-31 16:03:42', '2023-05-31 16:03:42'),
('aa7c1016-c1e6-47c4-974e-b11f2607a881', 'IU8uznXD15K3Tv7upFP2aMZGeqHlBkWX.jpg', '4e735530-c52a-4132-a12c-c93a439ac18b', 1, NULL, '2023-05-31 16:03:42', '2023-05-31 16:03:42'),
('b719299e-7cae-430c-ae9c-17e4d2daa257', 'ZdsiCV61uYPED4GfEFxvWJsCj9mt9ZNn.jpg', '51ecc6cd-b4fd-463b-ae0f-42578e4741fd', 0, NULL, '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('c9690bbd-2d0a-4628-bc22-7b3cbbe72e55', 'Bwc2XdDl0UODufLvhOlm6Pa0rdf2IDEK.jpg', '174dd17b-01c9-430b-8307-0090384cbe32', 1, NULL, '2023-05-31 16:03:46', '2023-05-31 16:03:46'),
('d171bff0-16b4-4be0-b138-a7cbd78bcaaf', '0l6VXyqEbSfLKsPnqXQ5Y9DU4jVdJH8S.jpg', 'c439c6ed-5171-42cd-9d1e-165bc0ae2b87', 0, NULL, '2023-05-31 16:03:44', '2023-05-31 16:03:44'),
('e2f603e8-05b4-4ec0-a4a1-3843a20f2da8', '18ugoiMvOcADNwhwD71eN3ZeFxf23Ilk.jpg', 'b5901174-26ff-4f68-af87-13419cc2cf11', 1, NULL, '2023-05-31 16:03:44', '2023-05-31 16:03:44'),
('e8e05130-eebc-4fcb-ac55-249306ce7a6d', '7dTFd5nWPhxxZEb8DfYHCLqUEaefNHZU.jpg', '51ecc6cd-b4fd-463b-ae0f-42578e4741fd', 1, NULL, '2023-05-31 16:03:46', '2023-05-31 16:03:46'),
('eb5c0727-29ca-4554-817e-8684ede5c963', 'LkMH0qYtmDdWPnLzVpoev6oLCvaFTN83.jpg', 'f1421951-1257-4d9d-be4a-f52daca85cf5', 0, NULL, '2023-05-31 16:03:42', '2023-05-31 16:03:42'),
('ed81aa5e-016b-4efd-94d7-0cd4e220c8a7', '7GshXBVrEMBWXHnCLBtxuE6JhqUEOQcv.jpg', 'cfdbb1df-68c9-47ed-922e-6a0fb38e32b8', 1, NULL, '2023-05-31 16:03:41', '2023-05-31 16:03:41'),
('ede9b36d-6167-48ac-8d72-d941084f4ec4', '0M0WkzL4VnwRGMTMRCtQdGpckjqjeplb.jpg', 'd11b1089-dd72-427b-861e-468e8ec626c1', 1, NULL, '2023-05-31 16:03:43', '2023-05-31 16:03:43'),
('eff02416-4967-4edb-bfce-2820fab1c5a6', '4c92YOH71R2Ew27cy5eAvur8zlOCFvDC.jpg', '9dc41559-0a46-4ffe-b6f5-afe9fe1aa0a3', 1, NULL, '2023-05-31 16:03:45', '2023-05-31 16:03:45'),
('f13d7f57-ff8c-4dc1-8f79-3f20b1ad627d', 'rulXeTmOjVoh5oyZbRupXwXWTS5VplCX.jpg', '49af54cb-82da-4dff-8363-e8dc02a29f1c', 0, NULL, '2023-05-31 16:03:46', '2023-05-31 16:03:46'),
('fa8023fe-7ce0-4e22-b922-e23b85c09aa2', 'uFeHXzdDxDRUDCf5qij6Dao56nJ9enK8.jpg', '28932168-9ce5-4b95-ae0f-14a65f20e058', 1, NULL, '2023-05-31 16:03:45', '2023-05-31 16:03:45'),
('fdb928af-2a13-4c66-9f44-54416c5a7d2a', 'g69BqxMzTcyY3DC1uc2bsbRbrIG9M0ih.jpg', '189596a1-ad7b-459b-8d06-428fe775cd07', 1, NULL, '2023-05-31 16:03:46', '2023-05-31 16:03:46');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2013_12_21_004244_create_roles_table', 1),
(2, '2014_10_12_000000_create_users_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2022_10_20_102137_create_categories_table', 1),
(7, '2022_11_20_102230_create_subcategories_table', 1),
(8, '2022_12_19_193305_create_gigs_table', 1),
(9, '2022_12_21_041055_create_otps_table', 1),
(10, '2022_12_21_150209_create_notification_categories_table', 1),
(11, '2022_12_22_074044_create_notifications_table', 1),
(12, '2022_12_27_154258_create_banner_categories_table', 1),
(13, '2022_12_28_130423_create_banners_table', 1),
(14, '2022_12_29_114350_create_ratings_table', 1),
(15, '2022_12_29_144546_create_wishlists_table', 1),
(16, '2022_12_29_144614_create_gig_images_table', 1),
(17, '2022_12_29_144701_create_plans_table', 1),
(18, '2023_02_12_162002_create_search_histories_table', 1),
(19, '2023_02_12_162352_create_view_gigs_histories_table', 1),
(20, '2023_02_12_162529_create_device_tokens_table', 1),
(21, '2023_02_17_135730_create_permissions_table', 1),
(22, '2023_02_17_143514_create_permission_role_table', 1),
(23, '2023_02_18_165517_create_email_subscriptions_table', 1),
(24, '2023_02_24_143827_create_freelancers_table', 1),
(25, '2023_03_13_095920_create_addresses_table', 1),
(26, '2023_03_26_085644_create_permissionables_table', 1),
(27, '2023_03_30_040942_create_studios_table', 1),
(28, '2023_03_31_055056_create_base_studio_schedules_table', 1),
(29, '2023_03_31_055828_create_studio_log_table', 1),
(30, '2023_04_01_072252_create_studio_events_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` char(36) NOT NULL,
  `data` text NOT NULL,
  `notification_category_id` char(36) NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_categories`
--

CREATE TABLE `notification_categories` (
  `id` char(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_categories`
--

INSERT INTO `notification_categories` (`id`, `title`, `deleted_at`, `created_at`, `updated_at`) VALUES
('2f2a0682-0419-4b32-84b9-250f58aecc43', 'Email Verified', NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('53d2d17a-fb18-4ee3-bb23-ebdf55830903', 'Order', NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('c862e071-e61a-4594-843a-37bf38be3012', 'Marketing', NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('c9bd92cc-c3a8-470d-8fa4-f3a840cb599d', 'Promo', NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('f4664b75-b92a-496f-81ba-c4e2c0f3d128', 'Event', NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24');

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

CREATE TABLE `otps` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `tries` int(11) NOT NULL DEFAULT 5,
  `otp` int(11) NOT NULL,
  `jwtv` varchar(64) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissionables`
--

CREATE TABLE `permissionables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` char(36) NOT NULL,
  `permissionable_id` char(36) NOT NULL,
  `permissionable_type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissionables`
--

INSERT INTO `permissionables` (`id`, `permission_id`, `permissionable_id`, `permissionable_type`, `created_at`, `updated_at`) VALUES
(1, '994cbef5-d787-4053-b664-9bf10cd7ff0b', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(2, '994cbef5-d7ea-46d1-ac57-18e11136484b', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(3, '994cbef5-d84e-408d-85c8-bd6014197020', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(4, '994cbef5-d899-4f4e-9a24-eb0bacf8a8aa', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(5, '994cbef5-d8d5-4386-aa29-d073752cb4fe', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(6, '994cbef5-d911-4b29-a143-0792665e57ad', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(7, '994cbef5-d952-4922-8883-44fcea81e351', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(8, '994cbef5-d98f-4f95-9797-d5b0bf52e9ae', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(9, '994cbef5-d9ea-45a0-93a8-61928f576a96', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(10, '994cbef5-da62-4de8-a99c-78078d0919d0', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(11, '994cbef5-dad4-4c60-a025-b1bc9b7c8571', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(12, '994cbef5-db3e-43c3-9235-74fee5a1b3c3', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(13, '994cbef5-dba9-463a-a538-06e26ecedd64', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(14, '994cbef5-dc12-4248-8c2f-4bb2658ff838', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(15, '994cbef5-dc7c-49ae-856f-3db49d2f6865', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(16, '994cbef5-dcdc-44df-9aa3-1aca8d54f5bf', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(17, '994cbef5-dd3c-4da7-9357-8ea5b2461f00', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(18, '994cbef5-dda1-47c0-b27d-2bf7c47a340e', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(19, '994cbef5-de04-449f-8cfa-752c3f0c1593', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(20, '994cbef5-de61-4cdc-bb63-79648fe2f8d2', '994cbef7-3384-49bb-aba6-b77d7f1b4653', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(21, '994cbef5-d787-4053-b664-9bf10cd7ff0b', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(22, '994cbef5-d7ea-46d1-ac57-18e11136484b', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(23, '994cbef5-d84e-408d-85c8-bd6014197020', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(24, '994cbef5-d899-4f4e-9a24-eb0bacf8a8aa', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(25, '994cbef5-d8d5-4386-aa29-d073752cb4fe', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(26, '994cbef5-d911-4b29-a143-0792665e57ad', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(27, '994cbef5-d952-4922-8883-44fcea81e351', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(28, '994cbef5-d98f-4f95-9797-d5b0bf52e9ae', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(29, '994cbef5-d9ea-45a0-93a8-61928f576a96', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(30, '994cbef5-da62-4de8-a99c-78078d0919d0', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(31, '994cbef5-dad4-4c60-a025-b1bc9b7c8571', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(32, '994cbef5-db3e-43c3-9235-74fee5a1b3c3', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(33, '994cbef5-dba9-463a-a538-06e26ecedd64', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(34, '994cbef5-dc12-4248-8c2f-4bb2658ff838', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(35, '994cbef5-dc7c-49ae-856f-3db49d2f6865', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(36, '994cbef5-dcdc-44df-9aa3-1aca8d54f5bf', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(37, '994cbef5-dd3c-4da7-9357-8ea5b2461f00', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(38, '994cbef5-dda1-47c0-b27d-2bf7c47a340e', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(39, '994cbef5-de04-449f-8cfa-752c3f0c1593', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(40, '994cbef5-de61-4cdc-bb63-79648fe2f8d2', '994cbef7-5592-4c93-8008-983a581bb837', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(41, '994cbef5-d787-4053-b664-9bf10cd7ff0b', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(42, '994cbef5-d7ea-46d1-ac57-18e11136484b', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(43, '994cbef5-d84e-408d-85c8-bd6014197020', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(44, '994cbef5-d899-4f4e-9a24-eb0bacf8a8aa', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(45, '994cbef5-d8d5-4386-aa29-d073752cb4fe', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(46, '994cbef5-d911-4b29-a143-0792665e57ad', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(47, '994cbef5-d952-4922-8883-44fcea81e351', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(48, '994cbef5-d98f-4f95-9797-d5b0bf52e9ae', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(49, '994cbef5-d9ea-45a0-93a8-61928f576a96', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(50, '994cbef5-da62-4de8-a99c-78078d0919d0', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(51, '994cbef5-dad4-4c60-a025-b1bc9b7c8571', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(52, '994cbef5-db3e-43c3-9235-74fee5a1b3c3', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(53, '994cbef5-dba9-463a-a538-06e26ecedd64', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(54, '994cbef5-dc12-4248-8c2f-4bb2658ff838', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(55, '994cbef5-dc7c-49ae-856f-3db49d2f6865', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(56, '994cbef5-dcdc-44df-9aa3-1aca8d54f5bf', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(57, '994cbef5-dd3c-4da7-9357-8ea5b2461f00', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(58, '994cbef5-dda1-47c0-b27d-2bf7c47a340e', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(59, '994cbef5-de04-449f-8cfa-752c3f0c1593', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(60, '994cbef5-de61-4cdc-bb63-79648fe2f8d2', '994cbef7-7711-4d90-b87b-97c1a1344ccf', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(61, '994cbef5-d787-4053-b664-9bf10cd7ff0b', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(62, '994cbef5-d7ea-46d1-ac57-18e11136484b', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(63, '994cbef5-d84e-408d-85c8-bd6014197020', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(64, '994cbef5-d899-4f4e-9a24-eb0bacf8a8aa', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(65, '994cbef5-d8d5-4386-aa29-d073752cb4fe', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(66, '994cbef5-d911-4b29-a143-0792665e57ad', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(67, '994cbef5-d952-4922-8883-44fcea81e351', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(68, '994cbef5-d98f-4f95-9797-d5b0bf52e9ae', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(69, '994cbef5-d9ea-45a0-93a8-61928f576a96', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(70, '994cbef5-da62-4de8-a99c-78078d0919d0', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(71, '994cbef5-dad4-4c60-a025-b1bc9b7c8571', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(72, '994cbef5-db3e-43c3-9235-74fee5a1b3c3', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(73, '994cbef5-dba9-463a-a538-06e26ecedd64', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(74, '994cbef5-dc12-4248-8c2f-4bb2658ff838', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(75, '994cbef5-dc7c-49ae-856f-3db49d2f6865', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(76, '994cbef5-dcdc-44df-9aa3-1aca8d54f5bf', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(77, '994cbef5-dd3c-4da7-9357-8ea5b2461f00', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(78, '994cbef5-dda1-47c0-b27d-2bf7c47a340e', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(79, '994cbef5-de04-449f-8cfa-752c3f0c1593', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(80, '994cbef5-de61-4cdc-bb63-79648fe2f8d2', '994cbef7-99eb-4fac-b2ac-1f0452a0bb6b', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(81, '994cbef5-d787-4053-b664-9bf10cd7ff0b', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(82, '994cbef5-d7ea-46d1-ac57-18e11136484b', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(83, '994cbef5-d84e-408d-85c8-bd6014197020', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(84, '994cbef5-d899-4f4e-9a24-eb0bacf8a8aa', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(85, '994cbef5-d8d5-4386-aa29-d073752cb4fe', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(86, '994cbef5-d911-4b29-a143-0792665e57ad', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(87, '994cbef5-d952-4922-8883-44fcea81e351', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(88, '994cbef5-d98f-4f95-9797-d5b0bf52e9ae', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(89, '994cbef5-d9ea-45a0-93a8-61928f576a96', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(90, '994cbef5-da62-4de8-a99c-78078d0919d0', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(91, '994cbef5-dad4-4c60-a025-b1bc9b7c8571', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(92, '994cbef5-db3e-43c3-9235-74fee5a1b3c3', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(93, '994cbef5-dba9-463a-a538-06e26ecedd64', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(94, '994cbef5-dc12-4248-8c2f-4bb2658ff838', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(95, '994cbef5-dc7c-49ae-856f-3db49d2f6865', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(96, '994cbef5-dcdc-44df-9aa3-1aca8d54f5bf', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(97, '994cbef5-dd3c-4da7-9357-8ea5b2461f00', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(98, '994cbef5-dda1-47c0-b27d-2bf7c47a340e', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(99, '994cbef5-de04-449f-8cfa-752c3f0c1593', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL),
(100, '994cbef5-de61-4cdc-bb63-79648fe2f8d2', '994cbef7-bc82-4e7d-aa08-8f6304193df0', 'App\\Models\\Auth\\Freelancer', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `created_at`, `updated_at`) VALUES
('994cbef5-d123-408d-8258-b4d1d52eb251', 'notifications-view', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d34f-43e9-b848-913945400d82', 'notifications-show', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d392-4947-8ebc-06079c37a8dc', 'notifications-update', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d430-42ac-b2d3-b885aaaf4c07', 'notifications-create', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d4b4-416f-a134-23e100ef155e', 'notifications-delete', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d523-40a2-93dd-519ebf41d0fa', 'users-view', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d58c-4d88-a714-1ee7ad3897e3', 'users-show', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d5f2-4d96-9e87-b3b5cc61aa64', 'users-update', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d659-4be8-a046-5327ee1460c1', 'users-create', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d6be-44e8-95c2-66cac66b91c7', 'users-delete', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d722-4a74-99ff-ed5fd424fd0b', ' users-view-all', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d787-4053-b664-9bf10cd7ff0b', 'gigs-view', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d7ea-46d1-ac57-18e11136484b', 'gigs-show', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d84e-408d-85c8-bd6014197020', 'gigs-update', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d899-4f4e-9a24-eb0bacf8a8aa', 'gigs-create', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d8d5-4386-aa29-d073752cb4fe', 'gigs-delete', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d911-4b29-a143-0792665e57ad', 'plans-view', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d952-4922-8883-44fcea81e351', 'plans-show', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d98f-4f95-9797-d5b0bf52e9ae', 'plans-update', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-d9ea-45a0-93a8-61928f576a96', 'plans-create', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-da62-4de8-a99c-78078d0919d0', 'plans-delete', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-dad4-4c60-a025-b1bc9b7c8571', 'gig-images-view', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-db3e-43c3-9235-74fee5a1b3c3', 'gig-images-show', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-dba9-463a-a538-06e26ecedd64', 'gig-images-update', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-dc12-4248-8c2f-4bb2658ff838', 'gig-images-create', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-dc7c-49ae-856f-3db49d2f6865', 'gig-images-delete', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-dcdc-44df-9aa3-1aca8d54f5bf', 'studio-schedules-view', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-dd3c-4da7-9357-8ea5b2461f00', 'studio-schedules-show', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-dda1-47c0-b27d-2bf7c47a340e', 'studio-schedules-update', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-de04-449f-8cfa-752c3f0c1593', 'studio-schedules-create', '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef5-de61-4cdc-bb63-79648fe2f8d2', 'studio-schedules-delete', '2023-05-31 16:03:23', '2023-05-31 16:03:23');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` char(36) NOT NULL,
  `permission_id` char(36) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`id`, `role_id`, `permission_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, '13afb267-a38f-4188-96e4-53387d4c8cdc', '994cbef5-d430-42ac-b2d3-b885aaaf4c07', NULL, NULL, NULL),
(2, '13afb267-a38f-4188-96e4-53387d4c8cdc', '994cbef5-d722-4a74-99ff-ed5fd424fd0b', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('STARTER','BUSINESS','ENTERPRISE') NOT NULL,
  `price` int(11) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `gig_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `type`, `price`, `data`, `gig_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'STARTER', 4973, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":10080}', 'cfdbb1df-68c9-47ed-922e-6a0fb38e32b8', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(2, 'BUSINESS', 14950, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', 'cfdbb1df-68c9-47ed-922e-6a0fb38e32b8', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(3, 'ENTERPRISE', 16242, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', 'cfdbb1df-68c9-47ed-922e-6a0fb38e32b8', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(4, 'STARTER', 4856, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', 'a344db0a-857a-4ac9-994b-cfb462197b2b', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(5, 'BUSINESS', 14099, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', 'a344db0a-857a-4ac9-994b-cfb462197b2b', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(6, 'ENTERPRISE', 15665, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', 'a344db0a-857a-4ac9-994b-cfb462197b2b', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(7, 'STARTER', 9556, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', '92cce5f7-f2bc-447a-bcc4-f72a75a3557b', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(8, 'BUSINESS', 16024, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', '92cce5f7-f2bc-447a-bcc4-f72a75a3557b', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(9, 'ENTERPRISE', 18781, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":90720}', '92cce5f7-f2bc-447a-bcc4-f72a75a3557b', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(10, 'STARTER', 7916, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', 'f1421951-1257-4d9d-be4a-f52daca85cf5', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(11, 'BUSINESS', 16975, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":80640}', 'f1421951-1257-4d9d-be4a-f52daca85cf5', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(12, 'ENTERPRISE', 20441, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":120960}', 'f1421951-1257-4d9d-be4a-f52daca85cf5', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(13, 'STARTER', 4658, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":10080}', 'ce59d42f-00f2-424e-818b-4cb885100b4c', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(14, 'BUSINESS', 14286, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', 'ce59d42f-00f2-424e-818b-4cb885100b4c', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(15, 'ENTERPRISE', 18675, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', 'ce59d42f-00f2-424e-818b-4cb885100b4c', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(16, 'STARTER', 5306, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', '4e735530-c52a-4132-a12c-c93a439ac18b', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(17, 'BUSINESS', 14576, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', '4e735530-c52a-4132-a12c-c93a439ac18b', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(18, 'ENTERPRISE', 23416, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', '4e735530-c52a-4132-a12c-c93a439ac18b', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(19, 'STARTER', 2940, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', 'd11b1089-dd72-427b-861e-468e8ec626c1', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(20, 'BUSINESS', 10201, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', 'd11b1089-dd72-427b-861e-468e8ec626c1', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(21, 'ENTERPRISE', 16435, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":90720}', 'd11b1089-dd72-427b-861e-468e8ec626c1', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(22, 'STARTER', 9034, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', 'c9e9da85-43d6-4bbd-a7aa-22baeff56a2d', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(23, 'BUSINESS', 17504, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":80640}', 'c9e9da85-43d6-4bbd-a7aa-22baeff56a2d', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(24, 'ENTERPRISE', 18525, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":120960}', 'c9e9da85-43d6-4bbd-a7aa-22baeff56a2d', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(25, 'STARTER', 2111, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":10080}', 'de98298c-6a0b-4cf4-8fd4-07cd8c32ab2f', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(26, 'BUSINESS', 6734, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', 'de98298c-6a0b-4cf4-8fd4-07cd8c32ab2f', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(27, 'ENTERPRISE', 11930, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', 'de98298c-6a0b-4cf4-8fd4-07cd8c32ab2f', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(28, 'STARTER', 7535, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', 'a3f53d63-98d9-437b-a277-b495e1c94baf', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(29, 'BUSINESS', 17397, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', 'a3f53d63-98d9-437b-a277-b495e1c94baf', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(30, 'ENTERPRISE', 26480, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', 'a3f53d63-98d9-437b-a277-b495e1c94baf', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(31, 'STARTER', 1087, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', 'b5901174-26ff-4f68-af87-13419cc2cf11', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(32, 'BUSINESS', 8513, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', 'b5901174-26ff-4f68-af87-13419cc2cf11', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(33, 'ENTERPRISE', 13747, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":90720}', 'b5901174-26ff-4f68-af87-13419cc2cf11', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(34, 'STARTER', 8252, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', '85a81312-43a2-4fca-ab56-5c344a555b7e', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(35, 'BUSINESS', 14000, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":80640}', '85a81312-43a2-4fca-ab56-5c344a555b7e', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(36, 'ENTERPRISE', 21966, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":120960}', '85a81312-43a2-4fca-ab56-5c344a555b7e', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(37, 'STARTER', 7251, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":10080}', 'c439c6ed-5171-42cd-9d1e-165bc0ae2b87', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(38, 'BUSINESS', 15028, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', 'c439c6ed-5171-42cd-9d1e-165bc0ae2b87', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(39, 'ENTERPRISE', 17765, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', 'c439c6ed-5171-42cd-9d1e-165bc0ae2b87', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(40, 'STARTER', 1884, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', '12109cd7-0891-46bf-8970-7d18565affd7', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(41, 'BUSINESS', 4453, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', '12109cd7-0891-46bf-8970-7d18565affd7', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(42, 'ENTERPRISE', 5466, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', '12109cd7-0891-46bf-8970-7d18565affd7', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(43, 'STARTER', 8824, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', '28932168-9ce5-4b95-ae0f-14a65f20e058', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(44, 'BUSINESS', 9897, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', '28932168-9ce5-4b95-ae0f-14a65f20e058', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(45, 'ENTERPRISE', 14952, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":90720}', '28932168-9ce5-4b95-ae0f-14a65f20e058', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(46, 'STARTER', 5664, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', 'c3c9fc7a-8ef9-44a4-9a93-080b6d948e91', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(47, 'BUSINESS', 15659, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":80640}', 'c3c9fc7a-8ef9-44a4-9a93-080b6d948e91', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(48, 'ENTERPRISE', 21352, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":120960}', 'c3c9fc7a-8ef9-44a4-9a93-080b6d948e91', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(49, 'STARTER', 1052, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":10080}', '9dc41559-0a46-4ffe-b6f5-afe9fe1aa0a3', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(50, 'BUSINESS', 6140, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', '9dc41559-0a46-4ffe-b6f5-afe9fe1aa0a3', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(51, 'ENTERPRISE', 15208, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', '9dc41559-0a46-4ffe-b6f5-afe9fe1aa0a3', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(52, 'STARTER', 3047, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', '189596a1-ad7b-459b-8d06-428fe775cd07', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(53, 'BUSINESS', 6581, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', '189596a1-ad7b-459b-8d06-428fe775cd07', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(54, 'ENTERPRISE', 16247, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', '189596a1-ad7b-459b-8d06-428fe775cd07', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(55, 'STARTER', 1901, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', '49af54cb-82da-4dff-8363-e8dc02a29f1c', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(56, 'BUSINESS', 8431, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":60480}', '49af54cb-82da-4dff-8363-e8dc02a29f1c', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(57, 'ENTERPRISE', 13713, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":90720}', '49af54cb-82da-4dff-8363-e8dc02a29f1c', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(58, 'STARTER', 8133, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":40320}', '174dd17b-01c9-430b-8307-0090384cbe32', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(59, 'BUSINESS', 11876, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":80640}', '174dd17b-01c9-430b-8307-0090384cbe32', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(60, 'ENTERPRISE', 18302, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":120960}', '174dd17b-01c9-430b-8307-0090384cbe32', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(61, 'STARTER', 9439, '{\"jumlah_hasil\":1,\"revisi\":0,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":10080}', '51ecc6cd-b4fd-463b-ae0f-42578e4741fd', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(62, 'BUSINESS', 19219, '{\"jumlah_hasil\":2,\"revisi\":1,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":20160}', '51ecc6cd-b4fd-463b-ae0f-42578e4741fd', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(63, 'ENTERPRISE', 23004, '{\"jumlah_hasil\":3,\"revisi\":2,\"file_format\":\"jpeg\",\"durasi_pengerjaan\":30240}', '51ecc6cd-b4fd-463b-ae0f-42578e4741fd', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
(64, 'STARTER', 2000, '{\"jumlah_hasil\":1,\"revisi\":2,\"file_format\":[\"jpg\",\"svg\"],\"durasi_pengerjaan\":3000000,\"lokasi\":\"Jakarta\"}', '7072975e-7403-428c-80f2-1a9098ce2412', '2023-06-03 17:56:04', '2023-06-03 17:56:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `gig_id` char(36) NOT NULL,
  `rating` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` char(36) NOT NULL,
  `title` varchar(255) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `title`, `deleted_at`, `created_at`, `updated_at`) VALUES
('13afb267-a38f-4188-96e4-53387d4c8cdc', 'admin', NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('171ca48f-8395-4eba-b201-3597427b349f', 'freelancer', NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'client', NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('9357e6e1-d01a-48d8-92ef-e95c8f018531', 'marketer', NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23');

-- --------------------------------------------------------

--
-- Table structure for table `search_histories`
--

CREATE TABLE `search_histories` (
  `id` char(36) NOT NULL,
  `search` varchar(255) NOT NULL,
  `user_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `studios`
--

CREATE TABLE `studios` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gig_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `studios`
--

INSERT INTO `studios` (`id`, `name`, `gig_id`, `created_at`, `updated_at`) VALUES
('994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'gigs studio event 1 studio', '49af54cb-82da-4dff-8363-e8dc02a29f1c', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'gigs studio event 2 studio', '174dd17b-01c9-430b-8307-0090384cbe32', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'gigs studio event 3 studio', '51ecc6cd-b4fd-463b-ae0f-42578e4741fd', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'gigs studio no address 1 studio', '945b10dd-9d9b-424f-8ec8-3d16ced514ca', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1e-1792-4dac-b40d-d163f99d76b9', 'gigs studio no address 2 studio', '039ab639-8203-4535-9f36-2de646b06f4d', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1f-2419-4ffe-a8cd-212bf33a338a', 'gigs studio no event 1 studio', '9dc41559-0a46-4ffe-b6f5-afe9fe1aa0a3', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-253c-485b-b4ae-4cd0291bdf18', 'gigs studio no event 2 studio', '189596a1-ad7b-459b-8d06-428fe775cd07', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-2647-4340-a04e-74fbeb797682', 'gigs studio no schedule 1 studio', '28932168-9ce5-4b95-ae0f-14a65f20e058', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-27ef-4133-a8bc-57e0160cbae2', 'gigs studio no schedule 2 studio', 'c3c9fc7a-8ef9-44a4-9a93-080b6d948e91', '2023-05-31 16:03:50', '2023-05-31 16:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `studio_events`
--

CREATE TABLE `studio_events` (
  `id` char(36) NOT NULL,
  `studio_id` char(36) NOT NULL,
  `status` enum('AVAILABLE','ON HOLD','BOOKED','EXPAIRED','CLOSED') NOT NULL,
  `hold_until` timestamp NULL DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `studio_events`
--

INSERT INTO `studio_events` (`id`, `studio_id`, `status`, `hold_until`, `start_time`, `end_time`, `created_at`, `updated_at`) VALUES
('994cbf19-ee0c-452a-8efd-7fc713af4d58', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-05-31 08:00:00', '2023-05-31 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-ee8c-4f9b-b567-62536d6271ce', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-05-31 10:01:00', '2023-05-31 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-ef07-4932-bc93-2b264e971269', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-05-31 13:00:00', '2023-05-31 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-ef83-4074-b80a-44793560c1f6', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-05-31 15:01:00', '2023-05-31 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f08f-451d-ab76-d6629f1f27de', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-01 08:00:00', '2023-06-01 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f112-4862-a31d-d4c49e8006f5', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-01 10:01:00', '2023-06-01 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f190-4587-8c52-328661cfbed4', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-01 13:00:00', '2023-06-01 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f210-449b-86be-ee57f04b5524', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-01 15:01:00', '2023-06-01 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f345-4c9c-96c1-cdd045868afa', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-02 08:00:00', '2023-06-02 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f3f8-41af-ab18-75f38c174f02', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-02 10:01:00', '2023-06-02 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f4a7-4c83-aced-497200bcf1d0', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-02 13:00:00', '2023-06-02 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f55d-40dc-ae1f-2b4612d74d3a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-02 15:01:00', '2023-06-02 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f6d4-451f-98bf-46cbb36ecce6', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-03 08:00:00', '2023-06-03 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f787-4c67-99e6-6a54d7a627af', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-03 10:01:00', '2023-06-03 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f83d-4b34-91ff-deb03246c920', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-03 13:00:00', '2023-06-03 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f8ce-4288-a037-a2339c6d6fb0', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-03 15:01:00', '2023-06-03 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-f9fd-4d7d-9159-8b9afa1bdc05', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-04 08:00:00', '2023-06-04 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-fa9d-4e04-bf6b-9f621f5ef4e8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-04 10:01:00', '2023-06-04 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-fb32-48d3-a71b-40cc89feae7f', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-04 13:00:00', '2023-06-04 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-fbc8-4dd2-8a22-349be327d8b2', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-04 15:01:00', '2023-06-04 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-fcd7-49fe-8717-b1b375ba7148', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-05 08:00:00', '2023-06-05 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-fd59-4f77-bb23-c852180ce0a7', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-05 10:01:00', '2023-06-05 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-fdd8-4ec7-b466-ecb53b3a5848', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-05 13:00:00', '2023-06-05 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-fe5a-46a3-bb4b-24d0bda29ba8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-05 15:01:00', '2023-06-05 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-ff6a-4f09-948c-63b62dcfc5cd', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-06 08:00:00', '2023-06-06 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf19-ffef-42bc-87e5-53451a185673', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-06 10:01:00', '2023-06-06 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-006b-4bc9-951c-e0a2c417dcfa', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-06 13:00:00', '2023-06-06 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-00e4-4af9-91dc-fdbf469017ac', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-06 15:01:00', '2023-06-06 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-01de-4f99-9a9d-6203c8e444a6', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-07 08:00:00', '2023-06-07 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-025b-40c5-86a2-4c64dd80e3a5', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-07 10:01:00', '2023-06-07 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-02e1-44f1-bb85-f72b5fce2b7e', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-07 13:00:00', '2023-06-07 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-0360-4613-b3cd-5d1fba191d41', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-07 15:01:00', '2023-06-07 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-0467-4109-9fe1-a4a39437f3b8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-08 08:00:00', '2023-06-08 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-04e8-4e30-99bd-0de0eca236ed', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-08 10:01:00', '2023-06-08 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-0566-4d70-bcce-c76cfe090ec8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-08 13:00:00', '2023-06-08 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-05e5-4d4b-a5c6-bcddc79d3c05', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-08 15:01:00', '2023-06-08 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-06e9-48c8-b1e5-f76842051ffb', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-09 08:00:00', '2023-06-09 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-076c-42d2-8297-9259c91af14b', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-09 10:01:00', '2023-06-09 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-07ed-47bb-b065-deea377d4cdf', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-09 13:00:00', '2023-06-09 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-086e-4495-a514-308145c4f2a2', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-09 15:01:00', '2023-06-09 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-097c-4a8a-afab-be219ae2b4ba', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-10 08:00:00', '2023-06-10 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-09ff-4e59-a373-67a75ba9b273', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-10 10:01:00', '2023-06-10 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-0a83-4bf2-b799-b40a0ec0ad25', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-10 13:00:00', '2023-06-10 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-0b08-4c4a-a8ff-23c40a4880ce', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-10 15:01:00', '2023-06-10 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-0ca7-4ba6-95bf-2c8ba94aa79c', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-11 08:00:00', '2023-06-11 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-0dc8-43a5-bb84-70a4a9f3c7b4', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-11 10:01:00', '2023-06-11 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-0ed6-4e44-a07c-51a6de6da095', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-11 13:00:00', '2023-06-11 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-0fd2-4bbd-b055-21163b4f4136', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-11 15:01:00', '2023-06-11 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1199-4322-b52f-7f8cb90246e1', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-12 08:00:00', '2023-06-12 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-129d-4b75-80e2-ea3d5d218998', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-12 10:01:00', '2023-06-12 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-136f-4b8b-b393-88163345ae33', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-12 13:00:00', '2023-06-12 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1430-469a-963f-a056cffba39e', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-12 15:01:00', '2023-06-12 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-158d-41eb-865d-009fe76f632e', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-13 08:00:00', '2023-06-13 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1633-4730-bb1a-597dfaea87d9', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-13 10:01:00', '2023-06-13 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-16e9-4645-8c9c-59f4d632e185', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-13 13:00:00', '2023-06-13 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-17bb-4d1b-872e-0967ddfeafa9', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-13 15:01:00', '2023-06-13 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1950-47c7-aa0d-c7a0673f1ef3', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-14 08:00:00', '2023-06-14 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1a0f-4762-a64d-c776cd02f335', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-14 10:01:00', '2023-06-14 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1ad0-4fc7-a051-ea23d453a4d8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-14 13:00:00', '2023-06-14 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1b6e-4be0-aac6-52d67645c086', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-14 15:01:00', '2023-06-14 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1cb8-4171-84cf-9700d482332f', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-15 08:00:00', '2023-06-15 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1d4e-4d63-a115-53608da2caf1', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-15 10:01:00', '2023-06-15 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1ddf-43a9-a3b5-32aa84197268', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-15 13:00:00', '2023-06-15 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1e72-47ec-9a00-73e734f24ed9', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-15 15:01:00', '2023-06-15 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-1fa6-4a26-a1c8-ba6702a9002c', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-16 08:00:00', '2023-06-16 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2038-4d5e-bc4b-8b39c17cd9fa', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-16 10:01:00', '2023-06-16 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-20ca-4002-a73e-e0fbaf2bdca2', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-16 13:00:00', '2023-06-16 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-215e-4ebf-a264-8945022f262f', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-16 15:01:00', '2023-06-16 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-227d-44c7-98c9-1609ef9878a0', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-17 08:00:00', '2023-06-17 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2313-458c-8ff0-40805b2eea69', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-17 10:01:00', '2023-06-17 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-23a7-4ed6-afbf-3828afc47226', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-17 13:00:00', '2023-06-17 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2441-415a-bcdf-e9652c5a2e3a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-17 15:01:00', '2023-06-17 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2563-4d6a-9426-988e9af0303d', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-18 08:00:00', '2023-06-18 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-25fb-4712-ae5b-d2d25e207c6e', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-18 10:01:00', '2023-06-18 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2692-49af-88bd-424cf5535a5f', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-18 13:00:00', '2023-06-18 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-272b-44d3-b375-5663dbdb4053', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-18 15:01:00', '2023-06-18 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2869-4eb3-bc8d-a73d2b14e54b', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-19 08:00:00', '2023-06-19 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-28fc-4ca9-9a31-f997e6c0e7fc', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-19 10:01:00', '2023-06-19 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2999-4b87-b964-4d5b7287db7a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-19 13:00:00', '2023-06-19 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2a3b-4d94-b138-a7ffef1b9295', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-19 15:01:00', '2023-06-19 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2b67-44d0-a32b-457b802edf54', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-20 08:00:00', '2023-06-20 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2c02-45ff-bc81-ecefef9964e5', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-20 10:01:00', '2023-06-20 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2c9f-4202-97f6-f4199616716a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-20 13:00:00', '2023-06-20 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2d3f-420c-b3bb-b8442d621270', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-20 15:01:00', '2023-06-20 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2e6f-46c0-8aa6-428e49498575', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-21 08:00:00', '2023-06-21 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2f11-436a-b45c-245380b33117', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-21 10:01:00', '2023-06-21 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-2fa7-4a39-a2a8-df7f2aba7917', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-21 13:00:00', '2023-06-21 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3019-4123-9390-831cd1d58626', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-21 15:01:00', '2023-06-21 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3117-4591-a56e-9724dfec7d41', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-22 08:00:00', '2023-06-22 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3190-4c27-81b0-b20994a474fb', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-22 10:01:00', '2023-06-22 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3217-4065-8e3b-b3b06bae27d4', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-22 13:00:00', '2023-06-22 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-32bf-4619-acb9-74c8b34d2398', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-22 15:01:00', '2023-06-22 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-34bb-494a-af56-89f55a4268e9', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-23 08:00:00', '2023-06-23 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-35b2-4eaa-809c-4dacafc3e22a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-23 10:01:00', '2023-06-23 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3690-46c9-a10c-fc4d6ad4f084', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-23 13:00:00', '2023-06-23 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3758-430f-9aed-db43bf15ef98', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-23 15:01:00', '2023-06-23 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3912-40db-8d9b-bcbe36279b3f', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-24 08:00:00', '2023-06-24 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-39d2-4775-a8de-03ff759e4a64', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-24 10:01:00', '2023-06-24 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3a8e-45fb-9f9e-cfcf295e1ee7', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-24 13:00:00', '2023-06-24 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3b3d-4491-bdc6-ae3c26d80477', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-24 15:01:00', '2023-06-24 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3c9c-4f38-83a4-2312b2b05c06', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-25 08:00:00', '2023-06-25 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3d41-4057-aeb5-5e7fbe0b8241', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-25 10:01:00', '2023-06-25 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3de1-4eaa-8d5c-30ed35ee7d55', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-25 13:00:00', '2023-06-25 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3e7a-4ec8-b385-d50938bddc3a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-25 15:01:00', '2023-06-25 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-3fbd-4eff-b1a6-71328a783b3c', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-26 08:00:00', '2023-06-26 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-403e-4124-bf44-b10465201f1c', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-26 10:01:00', '2023-06-26 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-40c1-4d5f-b18b-33eb6ed95f5f', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-26 13:00:00', '2023-06-26 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4142-4cd2-812c-350cec1d15de', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-26 15:01:00', '2023-06-26 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4271-4660-9b2c-4bff6334c57a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-27 08:00:00', '2023-06-27 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-42f4-4962-8ed7-cc3f6b48e4a7', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-27 10:01:00', '2023-06-27 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4379-453b-ac10-d95d244489ec', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-27 13:00:00', '2023-06-27 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-43f8-4ca8-b68a-4cb146a8f0ce', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-27 15:01:00', '2023-06-27 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-452d-4d81-9d39-a9376b231be7', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-28 08:00:00', '2023-06-28 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-45ae-49f9-9cb1-1877ebb3b6ce', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-28 10:01:00', '2023-06-28 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-462e-4693-ab67-beba9073d8f4', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-28 13:00:00', '2023-06-28 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-46ae-40d1-8a47-c22670b53176', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-28 15:01:00', '2023-06-28 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-47d5-4b2b-921a-ccaa61c45f84', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-29 08:00:00', '2023-06-29 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4852-4a79-b3d3-33dfbe1b8732', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-29 10:01:00', '2023-06-29 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-48d0-40ae-8b98-51ef75c04e00', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-29 13:00:00', '2023-06-29 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-494c-48f0-83b1-e497e6a0bab6', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-29 15:01:00', '2023-06-29 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4a82-4410-934b-1e20f7c991af', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-30 08:00:00', '2023-06-30 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4b00-46d9-aa95-1d249a1f0136', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-30 10:01:00', '2023-06-30 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4b7d-4b32-8f55-f7df96147a71', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-30 13:00:00', '2023-06-30 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4bf8-4c2f-90a3-328043fe0f48', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-06-30 15:01:00', '2023-06-30 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4d3f-4632-bc9a-f859b77f4002', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-01 08:00:00', '2023-07-01 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4dc5-4057-aa89-a45224caa083', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-01 10:01:00', '2023-07-01 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4e45-4a39-8058-3fb17f4f5f56', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-01 13:00:00', '2023-07-01 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4ebd-463d-a9ff-9e3241f5fd62', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-01 15:01:00', '2023-07-01 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-4fdd-4d32-9e52-91e6afe9bfc7', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-02 08:00:00', '2023-07-02 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-505e-49b0-a702-aefee86593fd', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-02 10:01:00', '2023-07-02 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-50de-426d-8e04-71ac78e3a245', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-02 13:00:00', '2023-07-02 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-515c-430c-b0d1-db5c18b1ef31', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-02 15:01:00', '2023-07-02 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-52bb-4d92-a04b-b86d911901ce', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-03 08:00:00', '2023-07-03 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-539b-48f3-923d-706e1f187703', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-03 10:01:00', '2023-07-03 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-547e-45b6-95ce-dc3fa46f9ba4', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-03 13:00:00', '2023-07-03 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-5555-4c38-80f6-de198c020ea3', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-03 15:01:00', '2023-07-03 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-5800-4a08-b500-60b6565cd9c6', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-04 08:00:00', '2023-07-04 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-58bf-4fae-a43d-5b4c177dba97', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-04 10:01:00', '2023-07-04 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-59ae-4a76-9b4d-ec2e7ae42995', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-04 13:00:00', '2023-07-04 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-5a9f-4e71-b5ac-6ae9f1ac43a3', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-04 15:01:00', '2023-07-04 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-5c73-4534-8259-a7dc4f7fe101', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-05 08:00:00', '2023-07-05 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-5daf-4a47-b61a-a64710e85162', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-05 10:01:00', '2023-07-05 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-5ec7-4157-ae59-bcdaa9509c8d', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-05 13:00:00', '2023-07-05 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-5f73-4daa-8d3c-21b4e3f05aca', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-05 15:01:00', '2023-07-05 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-60f4-475b-afb6-45fbd7434d34', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-06 08:00:00', '2023-07-06 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-619e-4d14-a68b-804896dec1be', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-06 10:01:00', '2023-07-06 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6246-4b9b-ab20-ed76c4ebc1a8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-06 13:00:00', '2023-07-06 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-62de-47ed-9f4d-b6508c6551ce', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-06 15:01:00', '2023-07-06 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6437-4a59-9295-1e94b10c3b10', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-07 08:00:00', '2023-07-07 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-64c4-4126-b362-a31c49e8fa8b', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-07 10:01:00', '2023-07-07 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-657e-4102-a649-ea6d14c4409b', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-07 13:00:00', '2023-07-07 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-664a-440e-bf70-e71c90603aef', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-07 15:01:00', '2023-07-07 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6898-47be-81fd-21d17ff60586', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-08 08:00:00', '2023-07-08 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6988-4eb5-8858-b7f67b42bd84', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-08 10:01:00', '2023-07-08 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6a69-4cfd-a32a-bf68ab6d50ca', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-08 13:00:00', '2023-07-08 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6b14-446d-8feb-05252a1ec3e4', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-08 15:01:00', '2023-07-08 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6ca3-4552-b448-2c170a2f131b', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-09 08:00:00', '2023-07-09 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6d4d-4239-9fd1-aeede7e7352e', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-09 10:01:00', '2023-07-09 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6df5-4bca-8253-96edacb57895', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-09 13:00:00', '2023-07-09 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6e93-4442-be61-9dc62bbac652', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-09 15:01:00', '2023-07-09 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-6ff8-459e-b47b-3bc584fa9229', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-10 08:00:00', '2023-07-10 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-708e-4d50-b528-99a73ac5e879', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-10 10:01:00', '2023-07-10 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7120-4711-aa56-afa1e2805722', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-10 13:00:00', '2023-07-10 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-71b6-438d-89b3-a862ee678746', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-10 15:01:00', '2023-07-10 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7319-4fcd-aaf2-8dc4a27ac502', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-11 08:00:00', '2023-07-11 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-73aa-48b0-a0d5-8305455efdc2', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-11 10:01:00', '2023-07-11 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-743a-4406-a225-3f66fc82fb02', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-11 13:00:00', '2023-07-11 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-74c7-493b-a838-66bcf19e7ffd', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-11 15:01:00', '2023-07-11 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7626-44a7-b1b7-76aa299f4036', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-12 08:00:00', '2023-07-12 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-76bc-4ace-8745-0a1a97d841b8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-12 10:01:00', '2023-07-12 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7743-4ea4-aa4f-8f040b7fc67a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-12 13:00:00', '2023-07-12 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-77cb-4127-bc66-91df16dabb1a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-12 15:01:00', '2023-07-12 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-78f9-49e8-8264-0f2ca2b7ce5d', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-13 08:00:00', '2023-07-13 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7988-4191-97e3-a5276337d8e0', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-13 10:01:00', '2023-07-13 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7a13-4c54-a642-f199c2f26364', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-13 13:00:00', '2023-07-13 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7a9f-4555-b178-bee36c7faace', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-13 15:01:00', '2023-07-13 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7bac-450f-8577-bc774e3ca7ac', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-14 08:00:00', '2023-07-14 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7c39-4922-83f1-8a5498f02e1a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-14 10:01:00', '2023-07-14 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7cc5-4ab9-b02a-867ee3f2ee2c', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-14 13:00:00', '2023-07-14 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7d56-4997-b293-979ea16d53fc', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-14 15:01:00', '2023-07-14 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7e6e-4fd5-87f2-21ebc577065a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-15 08:00:00', '2023-07-15 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7efd-400b-9a53-4e245918951a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-15 10:01:00', '2023-07-15 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-7f89-4b48-9616-356ab9a50465', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-15 13:00:00', '2023-07-15 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-801a-4466-ab83-d2e732f189dd', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-15 15:01:00', '2023-07-15 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8141-4c42-8abf-aeb740d75f44', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-16 08:00:00', '2023-07-16 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-81f8-4253-8626-fa4d19056dfc', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-16 10:01:00', '2023-07-16 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-82b3-4a36-a436-4d9acb225902', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-16 13:00:00', '2023-07-16 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8348-4003-bddf-7f89759f0e07', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-16 15:01:00', '2023-07-16 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-843b-48d9-a0c2-2b90468ed657', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-17 08:00:00', '2023-07-17 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-84c8-4c9f-ba3b-9ca1157c15e6', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-17 10:01:00', '2023-07-17 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8552-419d-827b-3a6f55542702', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-17 13:00:00', '2023-07-17 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-85dc-465a-9f8a-ae3677ede833', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-17 15:01:00', '2023-07-17 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-86cc-4bfa-b88a-3422a984af96', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-18 08:00:00', '2023-07-18 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8757-47f4-b11d-546db18da987', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-18 10:01:00', '2023-07-18 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-87e2-46cb-b281-09f42a70a70e', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-18 13:00:00', '2023-07-18 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-886c-4216-bd1e-7b57d3b665d7', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-18 15:01:00', '2023-07-18 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8959-4d2d-8f36-4f9f9ffecba4', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-19 08:00:00', '2023-07-19 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-89e5-43d4-b128-32b58a7188cb', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-19 10:01:00', '2023-07-19 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8a6f-4336-af8c-b28a63d991aa', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-19 13:00:00', '2023-07-19 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8b04-45ec-8d90-2d86a4de1441', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-19 15:01:00', '2023-07-19 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8bf2-47bb-a52f-3ce6ffeb5838', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-20 08:00:00', '2023-07-20 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8c88-462a-86e8-0995778a62c4', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-20 10:01:00', '2023-07-20 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8d16-4d7b-91f5-18056af6c7b2', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-20 13:00:00', '2023-07-20 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8dd2-4941-8aff-23ddd98bb97a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-20 15:01:00', '2023-07-20 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8ec9-4b3e-9284-097941e9b252', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-21 08:00:00', '2023-07-21 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-8f82-4925-90eb-1b2c4b27478f', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-21 10:01:00', '2023-07-21 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9011-4478-b702-0dddb0fe706b', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-21 13:00:00', '2023-07-21 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-90a1-40fe-bd39-96a21028b291', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-21 15:01:00', '2023-07-21 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9193-4fbe-93a2-80cb87684c83', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-22 08:00:00', '2023-07-22 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9226-473d-b273-1c3009f16026', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-22 10:01:00', '2023-07-22 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-92b1-4de0-919d-412dc3f1e811', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-22 13:00:00', '2023-07-22 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-933e-41de-ab8d-53c4988867b2', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-22 15:01:00', '2023-07-22 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-942d-48c2-abd0-8dba8493e388', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-23 08:00:00', '2023-07-23 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-94bb-41dc-a7b2-1e34545d7937', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-23 10:01:00', '2023-07-23 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9586-4eb7-a6d7-13a78f48deb3', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-23 13:00:00', '2023-07-23 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-969e-48e8-92f9-61f629995694', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-23 15:01:00', '2023-07-23 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9834-4f3a-9722-c10c6e2dc252', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-24 08:00:00', '2023-07-24 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-993e-4173-aa1d-7f45ea7484b8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-24 10:01:00', '2023-07-24 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9a01-4f61-8f07-b623008f6fa4', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-24 13:00:00', '2023-07-24 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9abe-4251-a5c0-ad9f863708a8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-24 15:01:00', '2023-07-24 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9bee-4910-8898-9f2779758aa8', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-25 08:00:00', '2023-07-25 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9cab-4b3d-9fdc-e1edd1965318', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-25 10:01:00', '2023-07-25 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9d65-4ebf-a1c8-5eb5d98bfaca', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-25 13:00:00', '2023-07-25 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9dfc-4b39-9422-c24c18320093', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-25 15:01:00', '2023-07-25 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-9f99-4465-8e26-761d04bb43b1', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-26 08:00:00', '2023-07-26 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a09d-4cb8-bfd6-6738b8c4d7bb', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-26 10:01:00', '2023-07-26 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a180-4631-9966-4c91271d6444', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-26 13:00:00', '2023-07-26 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a23e-4194-8f1c-c122af85a5b6', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-26 15:01:00', '2023-07-26 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a36f-4190-b33e-5edd702355b6', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-27 08:00:00', '2023-07-27 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a430-4dab-90fa-0306456df39a', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-27 10:01:00', '2023-07-27 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a4ee-4630-8a04-c8d3baee56e1', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-27 13:00:00', '2023-07-27 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a593-48a4-865b-2b9bb7305fe3', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-27 15:01:00', '2023-07-27 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a690-4726-b8a2-e2a44ed2f7ec', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-28 08:00:00', '2023-07-28 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a729-487f-9790-a0b1cb17ac54', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-28 10:01:00', '2023-07-28 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a82f-4767-b8ac-7c78c8110e85', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-28 13:00:00', '2023-07-28 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-a958-4c1b-bbc2-466235d2b482', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-28 15:01:00', '2023-07-28 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ab3d-4144-ad25-761626b85e22', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-29 08:00:00', '2023-07-29 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ac36-4e7a-ba3f-509b79fcd2af', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-29 10:01:00', '2023-07-29 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-accd-4b31-84e6-65bb98424159', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-29 13:00:00', '2023-07-29 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ad64-4455-8b3d-be9fd1df940b', '994cbf19-eb17-4dad-b7d6-b9037c251bd3', 'AVAILABLE', NULL, '2023-07-29 15:01:00', '2023-07-29 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-af43-4fb0-b266-5b978adb6874', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-05-31 08:00:00', '2023-05-31 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-afb6-48de-92eb-012ca3aa3d5a', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-05-31 10:01:00', '2023-05-31 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b026-402c-bc6f-dbf1a69602ed', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-05-31 13:00:00', '2023-05-31 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b096-4b7c-9f05-277ceb2c11dd', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-05-31 15:01:00', '2023-05-31 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b169-46b2-a0e9-6745cb861db4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-01 08:00:00', '2023-06-01 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b1dc-4079-8715-a3ce35d31f24', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-01 10:01:00', '2023-06-01 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b24d-4f20-9457-98adae7e6395', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-01 13:00:00', '2023-06-01 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b2be-40e5-ac7c-9c3dd7a3d18f', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-01 15:01:00', '2023-06-01 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b390-4c2b-90fc-95ddf5388198', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-02 08:00:00', '2023-06-02 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b40a-4fbd-9ca1-41ef8ba76825', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-02 10:01:00', '2023-06-02 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b480-422c-9e14-0fb0170c7d0f', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-02 13:00:00', '2023-06-02 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b4f5-4c3e-a2a1-f40a9b523854', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-02 15:01:00', '2023-06-02 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b5cb-4899-8e13-fe03d480914e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-03 08:00:00', '2023-06-03 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b642-47b0-9bad-da041f1b49fc', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-03 10:01:00', '2023-06-03 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b6b9-4ba2-af8f-24c7a1321712', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-03 13:00:00', '2023-06-03 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b72f-45e8-a913-1a595863a8d4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-03 15:01:00', '2023-06-03 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b82c-474c-a408-138bb0235549', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-04 08:00:00', '2023-06-04 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-b924-4f2b-a33d-2914528a74c7', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-04 10:01:00', '2023-06-04 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ba14-44ca-914a-1e12d872acb8', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-04 13:00:00', '2023-06-04 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-bb04-4632-b4e8-fe285167ea74', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-04 15:01:00', '2023-06-04 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-bcbc-48ce-b662-91678d59c51a', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-05 08:00:00', '2023-06-05 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47');
INSERT INTO `studio_events` (`id`, `studio_id`, `status`, `hold_until`, `start_time`, `end_time`, `created_at`, `updated_at`) VALUES
('994cbf1a-bd5f-4841-a2e0-b9852139306d', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-05 10:01:00', '2023-06-05 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-be00-4438-b772-764e1d36637c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-05 13:00:00', '2023-06-05 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-bea5-44ff-84d5-44f3bc7bb710', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-05 15:01:00', '2023-06-05 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-bfc5-4e6f-8664-3a3f23dcd148', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-06 08:00:00', '2023-06-06 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c06b-4c6a-b677-a768c0b6c362', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-06 10:01:00', '2023-06-06 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c102-48d7-a7e4-144fe6553728', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-06 13:00:00', '2023-06-06 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c18d-4eb8-9479-f1a90cb7ad96', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-06 15:01:00', '2023-06-06 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c27f-403f-aae9-bfb98f2c611b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-07 08:00:00', '2023-06-07 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c30e-4d8d-9fb9-170bab2b43b8', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-07 10:01:00', '2023-06-07 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c39c-4159-9285-954665e29240', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-07 13:00:00', '2023-06-07 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c42d-40cb-a440-0ac58083361b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-07 15:01:00', '2023-06-07 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c51a-40f8-9993-16febc215551', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-08 08:00:00', '2023-06-08 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c5a0-43fc-890b-5c7ffacefd50', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-08 10:01:00', '2023-06-08 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c623-4370-9ee3-cff5da00bafa', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-08 13:00:00', '2023-06-08 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c6a7-4e30-8819-d12478fe2982', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-08 15:01:00', '2023-06-08 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c78c-42c6-bd65-61d232958b62', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-09 08:00:00', '2023-06-09 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c814-4111-8ebc-d4b3c5f9bdf5', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-09 10:01:00', '2023-06-09 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c89c-4da1-8e82-0a52b7397618', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-09 13:00:00', '2023-06-09 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-c925-4e28-b9e3-ce24d7a3e81d', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-09 15:01:00', '2023-06-09 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ca0b-45e7-a6b3-fa616e90a10c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-10 08:00:00', '2023-06-10 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ca95-4a6e-8811-4cc00eb3bd59', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-10 10:01:00', '2023-06-10 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-cb23-4e4f-92e8-c4f3e67f8145', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-10 13:00:00', '2023-06-10 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-cbad-4890-bd17-4cb88930c540', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-10 15:01:00', '2023-06-10 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-cc9a-4be9-b296-6c56b764a634', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-11 08:00:00', '2023-06-11 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-cd27-4598-8476-ae8beee95c68', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-11 10:01:00', '2023-06-11 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-cdb2-4a2e-b03d-9fe7a0a9e65d', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-11 13:00:00', '2023-06-11 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ce43-4f43-85d9-5c43c832eb43', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-11 15:01:00', '2023-06-11 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-cf70-4f77-8bac-68ea624f4499', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-12 08:00:00', '2023-06-12 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d035-42a9-9d52-75f5a05e7f6e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-12 10:01:00', '2023-06-12 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d0f7-447b-ae3d-6b267735f3e0', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-12 13:00:00', '2023-06-12 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d18b-4d15-9e1f-d8f71144fa5b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-12 15:01:00', '2023-06-12 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d2a2-4317-a2f4-ad70f95a982e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-13 08:00:00', '2023-06-13 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d335-4e93-b848-0cbb3b82fad0', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-13 10:01:00', '2023-06-13 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d3c8-4504-ab2f-f056e81d19c5', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-13 13:00:00', '2023-06-13 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d45a-4fb6-9577-f505a667a11e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-13 15:01:00', '2023-06-13 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d560-48b0-8ba2-7c4f807e87ea', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-14 08:00:00', '2023-06-14 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d5f8-40c0-94c9-ab380c190f10', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-14 10:01:00', '2023-06-14 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d6d9-42e0-be79-5b151345be79', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-14 13:00:00', '2023-06-14 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d771-4100-99eb-f9b15e101088', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-14 15:01:00', '2023-06-14 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d87d-44b2-a2df-d30cebe48594', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-15 08:00:00', '2023-06-15 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d915-4cf0-a13a-9f358640226c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-15 10:01:00', '2023-06-15 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-d9ac-4c40-852f-27f1f4d9adf5', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-15 13:00:00', '2023-06-15 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-da45-4a77-9e72-7643ec9dcfc4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-15 15:01:00', '2023-06-15 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-db4f-4153-861b-5e12c1b852bd', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-16 08:00:00', '2023-06-16 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-dbf3-457d-9fde-d8b6c0958cae', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-16 10:01:00', '2023-06-16 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-dc8e-42e5-9188-3f9981f0a8ba', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-16 13:00:00', '2023-06-16 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-dd64-4b97-b9ce-22b5a6dea4bb', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-16 15:01:00', '2023-06-16 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-de6e-48f0-ab1f-1770ced7f9b3', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-17 08:00:00', '2023-06-17 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-df0c-4ff5-a590-b526b64583a9', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-17 10:01:00', '2023-06-17 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-dfa8-48b9-811a-94d4416e8160', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-17 13:00:00', '2023-06-17 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e045-40e2-877e-6eaeb530c3c4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-17 15:01:00', '2023-06-17 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e151-4df4-896c-f81d035e3fb4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-18 08:00:00', '2023-06-18 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e1f1-4a38-a369-3e50c63b3021', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-18 10:01:00', '2023-06-18 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e291-4b0f-8b0c-c1e0d27a6144', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-18 13:00:00', '2023-06-18 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e330-49f4-9b26-79e24776a9f6', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-18 15:01:00', '2023-06-18 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e435-499e-9388-59d3b5addaeb', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-19 08:00:00', '2023-06-19 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e4d8-4491-98ba-153b45302815', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-19 10:01:00', '2023-06-19 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e57c-4973-8e21-f8f69e08c52c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-19 13:00:00', '2023-06-19 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e621-44c3-8e0a-9b98c8e0e007', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-19 15:01:00', '2023-06-19 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e721-41b7-886a-7d4feb32281b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-20 08:00:00', '2023-06-20 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e7ca-4798-aafe-f1421e6decb6', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-20 10:01:00', '2023-06-20 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e86f-4201-8600-41d9c0ecac49', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-20 13:00:00', '2023-06-20 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-e916-47eb-8903-a17c8d1c819e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-20 15:01:00', '2023-06-20 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ea1f-4ff7-8ecd-15fc3f87cb04', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-21 08:00:00', '2023-06-21 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-eac8-4c7d-b300-c14366e69586', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-21 10:01:00', '2023-06-21 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-eb6f-4125-a69d-e81de66cc82b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-21 13:00:00', '2023-06-21 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ec19-4a30-abd5-292802f3d11e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-21 15:01:00', '2023-06-21 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ed26-4658-a96d-bf7b3ce6849c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-22 08:00:00', '2023-06-22 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-edd3-48ad-b91c-d3c31347e641', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-22 10:01:00', '2023-06-22 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ee7f-4931-90b2-3b6d65bec24a', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-22 13:00:00', '2023-06-22 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ef2d-4f60-a9d4-cdf365431b9f', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-22 15:01:00', '2023-06-22 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f03b-4645-a0f3-09326d70c810', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-23 08:00:00', '2023-06-23 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f0e9-46a7-9f0c-c63586e23e73', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-23 10:01:00', '2023-06-23 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f199-4517-bae7-31fc109e8c7c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-23 13:00:00', '2023-06-23 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f248-466f-8636-9726629bc2fa', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-23 15:01:00', '2023-06-23 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f357-4b09-8d4e-8941d71dcd93', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-24 08:00:00', '2023-06-24 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f407-47b9-9cf2-862bf0ba20a4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-24 10:01:00', '2023-06-24 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f4dd-4c65-b008-aeb36a44a364', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-24 13:00:00', '2023-06-24 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f5c1-4bc7-8853-688a9284bb71', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-24 15:01:00', '2023-06-24 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f73c-4558-8384-5bf86a6b7dfb', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-25 08:00:00', '2023-06-25 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f82d-4506-8d36-6c04f6bf68b5', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-25 10:01:00', '2023-06-25 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f8ea-4cd8-be4b-0f2f4811fae7', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-25 13:00:00', '2023-06-25 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-f9ae-4098-a8db-6e444ff8caf6', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-25 15:01:00', '2023-06-25 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-facd-436d-8158-fac43a62bd68', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-26 08:00:00', '2023-06-26 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-fb89-43ca-9071-4732da9a85c7', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-26 10:01:00', '2023-06-26 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-fc45-408c-b6df-89a57d9a3f18', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-26 13:00:00', '2023-06-26 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-fcff-449e-8848-afea81a02a91', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-26 15:01:00', '2023-06-26 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-fe17-489d-9277-2aeb9c6f1c2d', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-27 08:00:00', '2023-06-27 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-fed7-46dd-97cc-47c56a9cfe39', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-27 10:01:00', '2023-06-27 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1a-ff95-4952-9a13-a5bdb1ae4e06', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-27 13:00:00', '2023-06-27 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0055-4b28-9e25-5291f824360b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-27 15:01:00', '2023-06-27 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0175-4b35-992b-a9a4f4595c97', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-28 08:00:00', '2023-06-28 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0234-4869-9fd0-0f48c05701cd', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-28 10:01:00', '2023-06-28 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-02f3-42f9-ab15-a724994233f9', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-28 13:00:00', '2023-06-28 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-03b1-4a04-8053-c628cf73dcb9', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-28 15:01:00', '2023-06-28 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-04d0-4266-b20c-495cfb4f3c4f', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-29 08:00:00', '2023-06-29 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0592-4862-91ec-34ae2dbeb9c9', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-29 10:01:00', '2023-06-29 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0653-47e2-9f78-cdd91792e93b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-29 13:00:00', '2023-06-29 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-071c-46d3-b2cd-cdf4a37374a4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-29 15:01:00', '2023-06-29 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0925-4e00-ad78-49f5f22fda99', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-30 08:00:00', '2023-06-30 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0a5c-4ad4-b41b-c26584091b37', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-30 10:01:00', '2023-06-30 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0b86-41a5-abbd-c49bfc3872e7', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-30 13:00:00', '2023-06-30 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0c98-4d0b-8345-dc38023f71be', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-06-30 15:01:00', '2023-06-30 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0e22-4d45-afd8-7f3df1f90946', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-01 08:00:00', '2023-07-01 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-0f1c-46f7-b126-88c9d26b344e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-01 10:01:00', '2023-07-01 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-1006-4197-9baa-30fbaf4fa084', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-01 13:00:00', '2023-07-01 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-10d7-4c4c-bfb7-c6c36d0f4a54', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-01 15:01:00', '2023-07-01 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-128d-44e2-bd3a-c8c653a29434', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-02 08:00:00', '2023-07-02 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-1423-402a-a543-3eef1761afb1', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-02 10:01:00', '2023-07-02 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-15b8-43e4-be57-e7e84bf37322', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-02 13:00:00', '2023-07-02 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-177e-4ccb-a152-088f04fcdfb2', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-02 15:01:00', '2023-07-02 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-1a03-4094-8723-608f357a0601', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-03 08:00:00', '2023-07-03 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-1bc2-4d19-8541-efabc31e6eb6', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-03 10:01:00', '2023-07-03 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-1d3f-4709-ae87-0f7795efc5a9', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-03 13:00:00', '2023-07-03 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-1ed7-48a4-8ec9-88b895ef3dfe', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-03 15:01:00', '2023-07-03 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-2101-474a-befb-43be50030f04', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-04 08:00:00', '2023-07-04 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-22aa-4a63-9b26-dac66ee4a5f8', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-04 10:01:00', '2023-07-04 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-247e-410b-8b9d-0f14d53f9eff', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-04 13:00:00', '2023-07-04 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-264f-47a7-a304-c0022e7f1fc7', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-04 15:01:00', '2023-07-04 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-284c-47da-84e6-ed55ebde21ec', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-05 08:00:00', '2023-07-05 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-2988-4b25-a3cd-582b94b3b740', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-05 10:01:00', '2023-07-05 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-2acc-4278-8651-9a55270bcd88', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-05 13:00:00', '2023-07-05 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-2c1f-4c8a-a362-ebab37e84df6', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-05 15:01:00', '2023-07-05 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-2e37-445c-aeba-80970f4c8317', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-06 08:00:00', '2023-07-06 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-2fa7-4dd1-9883-ae424e33d81e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-06 10:01:00', '2023-07-06 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-30df-48ac-a660-e7d95c12ce7e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-06 13:00:00', '2023-07-06 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-3215-4573-a02b-89db7bace7b0', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-06 15:01:00', '2023-07-06 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-33a7-44a5-ae56-943ee3e9b28a', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-07 08:00:00', '2023-07-07 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-34ac-4ec0-841f-a324ffaa81e1', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-07 10:01:00', '2023-07-07 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-35aa-4f9d-9c9b-9c186b6f31f2', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-07 13:00:00', '2023-07-07 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-36ac-46d3-a23b-95eadf76c37a', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-07 15:01:00', '2023-07-07 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-3829-4bb9-b976-c67a2f6fd7b4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-08 08:00:00', '2023-07-08 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-3922-4776-b75f-e4da59ab09ac', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-08 10:01:00', '2023-07-08 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-3a24-4ac9-bdca-e1c1edfa8b47', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-08 13:00:00', '2023-07-08 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-3b1b-4245-b6ce-ab23338bbc8f', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-08 15:01:00', '2023-07-08 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-3c71-4074-a7d0-4c7d15b07c8d', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-09 08:00:00', '2023-07-09 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-3d5b-4aa2-805f-169d09a76134', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-09 10:01:00', '2023-07-09 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-3e40-4620-8525-f02ac04e9a30', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-09 13:00:00', '2023-07-09 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-3f21-4f56-8229-2e6062239624', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-09 15:01:00', '2023-07-09 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-4061-482d-95a4-33d3202aceca', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-10 08:00:00', '2023-07-10 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-414e-459d-ad22-a9f5c1da2610', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-10 10:01:00', '2023-07-10 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-4238-4a61-b05c-a039ee86f9e1', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-10 13:00:00', '2023-07-10 15:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-4324-448d-aaa1-78aa6ff31e29', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-10 15:01:00', '2023-07-10 18:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-447a-4eff-97c3-628bf18f8907', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-11 08:00:00', '2023-07-11 10:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-4584-4139-9427-48bab48f4188', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-11 10:01:00', '2023-07-11 12:00:00', '2023-05-31 16:03:47', '2023-05-31 16:03:47'),
('994cbf1b-46c2-447d-9904-478797cf494e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-11 13:00:00', '2023-07-11 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-48d1-43d8-a6c5-830bac89dd63', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-11 15:01:00', '2023-07-11 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-4b80-45c2-8b1c-e5988f1b7aff', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-12 08:00:00', '2023-07-12 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-4d15-4291-a272-c5948388d6a0', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-12 10:01:00', '2023-07-12 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-4ead-4554-aff3-af66f3ed9460', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-12 13:00:00', '2023-07-12 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-4fd9-4377-a11f-f2b4db3209a9', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-12 15:01:00', '2023-07-12 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-51e0-4833-a777-5f51c246e24b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-13 08:00:00', '2023-07-13 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-52fc-4f3f-b3ae-bfdacff927d6', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-13 10:01:00', '2023-07-13 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-53fc-4200-8315-0e64bf767737', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-13 13:00:00', '2023-07-13 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-54fc-48b1-94d7-c1047777be9a', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-13 15:01:00', '2023-07-13 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-5697-4a67-af04-0b46065effbc', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-14 08:00:00', '2023-07-14 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-57b3-4501-9da0-d95e6caca6a8', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-14 10:01:00', '2023-07-14 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-592d-4105-8c07-fbc2b77c29d6', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-14 13:00:00', '2023-07-14 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-5a9a-4c32-b6a4-fc233025babe', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-14 15:01:00', '2023-07-14 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-5d01-4cef-81e2-07b9bb5744fc', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-15 08:00:00', '2023-07-15 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-5e5d-4628-a9d1-4cf2bb46f725', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-15 10:01:00', '2023-07-15 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-5f7e-44bf-9633-120aef78ae15', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-15 13:00:00', '2023-07-15 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-60a3-4681-a583-d09942692575', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-15 15:01:00', '2023-07-15 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-626b-4191-a54b-484dbd2d89c4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-16 08:00:00', '2023-07-16 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-637d-4394-bf2a-c1f1e084486f', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-16 10:01:00', '2023-07-16 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-647e-48c0-a59a-7fc6b6a59909', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-16 13:00:00', '2023-07-16 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-6589-497b-bd44-277fa92f2a0b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-16 15:01:00', '2023-07-16 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-6709-468f-ba59-2df95bafdbd4', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-17 08:00:00', '2023-07-17 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-680f-4e06-b2ab-e4881cbd458c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-17 10:01:00', '2023-07-17 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-6911-4632-bcd0-e97166dc05da', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-17 13:00:00', '2023-07-17 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-6a40-4f61-ba12-2f17b85f0706', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-17 15:01:00', '2023-07-17 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-6c68-4303-a93a-439aebb2db88', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-18 08:00:00', '2023-07-18 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-6e0b-4c26-bfe8-b7660d697d1c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-18 10:01:00', '2023-07-18 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-6f29-493f-bc40-1e0c41ab724e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-18 13:00:00', '2023-07-18 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-703f-48f3-8153-d338a60109b1', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-18 15:01:00', '2023-07-18 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-71d6-464b-9b51-c74a229b3b5c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-19 08:00:00', '2023-07-19 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-72e1-44b5-a1cb-d7fc1af0a30c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-19 10:01:00', '2023-07-19 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-73f0-4756-8fb6-7e6f3504aa08', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-19 13:00:00', '2023-07-19 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-754e-4664-9de9-7a1602944774', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-19 15:01:00', '2023-07-19 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-77bb-40b1-8f7d-96dc992c1aa9', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-20 08:00:00', '2023-07-20 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-794a-4cf0-948b-acfd759b9fab', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-20 10:01:00', '2023-07-20 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-7a9f-401a-8581-ffde9c3dd0e6', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-20 13:00:00', '2023-07-20 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-7be6-4856-8ca1-761c2fb03c02', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-20 15:01:00', '2023-07-20 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-7dc7-412d-9b57-04c82dec0dc5', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-21 08:00:00', '2023-07-21 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-7ef2-46a4-a4f3-75c8118766c9', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-21 10:01:00', '2023-07-21 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8010-4794-a6d3-2de973e619fb', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-21 13:00:00', '2023-07-21 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8139-45d7-a547-fddc38ef7080', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-21 15:01:00', '2023-07-21 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-82e2-4109-9230-7bf97bdfd475', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-22 08:00:00', '2023-07-22 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8406-4368-9d48-51f2ffe75b38', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-22 10:01:00', '2023-07-22 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8528-494e-a213-952fe64a496c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-22 13:00:00', '2023-07-22 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8649-4d7a-861d-33cdcc8c8c92', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-22 15:01:00', '2023-07-22 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-87dd-4209-a1e0-00dbbe24957e', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-23 08:00:00', '2023-07-23 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-88fc-43aa-a5d1-f765a3fe97b1', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-23 10:01:00', '2023-07-23 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8a16-4a3c-96f2-c83e760563bd', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-23 13:00:00', '2023-07-23 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8b2e-4091-8c10-66e0f0a83d02', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-23 15:01:00', '2023-07-23 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8cbd-4ddf-a33a-266505cd9cc8', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-24 08:00:00', '2023-07-24 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8dd9-498b-8f1c-2f60e00ae0a5', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-24 10:01:00', '2023-07-24 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-8ef6-4faf-a8c9-93572f10fdf7', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-24 13:00:00', '2023-07-24 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-901d-4733-81e3-7ca692894d32', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-24 15:01:00', '2023-07-24 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-91db-4ff0-a861-5564f4ff5177', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-25 08:00:00', '2023-07-25 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-93c5-4dbb-bccf-0751893de245', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-25 10:01:00', '2023-07-25 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-9590-4607-b1e9-d40255b21779', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-25 13:00:00', '2023-07-25 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-9848-4733-9c0b-9d5761e9adbb', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-25 15:01:00', '2023-07-25 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-9afe-4fdc-acab-5043c9e6ba5c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-26 08:00:00', '2023-07-26 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-9ce6-44ee-8e07-96aba4de407b', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-26 10:01:00', '2023-07-26 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-9e6b-4f13-a19b-720dbd5fd137', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-26 13:00:00', '2023-07-26 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-a029-4e14-91cf-786cc2ff3287', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-26 15:01:00', '2023-07-26 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-a263-407e-9059-8d29b5470361', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-27 08:00:00', '2023-07-27 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-a3ba-4257-867b-e254e0cfc729', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-27 10:01:00', '2023-07-27 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-a512-4e09-acf5-0fbd5e4d352d', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-27 13:00:00', '2023-07-27 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-a656-4ebb-b59f-59955c34d16a', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-27 15:01:00', '2023-07-27 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-a82e-40c3-b321-fe5d7ee2e49a', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-28 08:00:00', '2023-07-28 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-a9eb-4b8b-9a78-ab770da0ed9c', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-28 10:01:00', '2023-07-28 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ab31-41f3-ab07-a74b8b7daf67', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-28 13:00:00', '2023-07-28 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ac74-4e47-927b-499aa0f9f5e2', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-28 15:01:00', '2023-07-28 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ae5a-4182-8409-268504cd29d8', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-29 08:00:00', '2023-07-29 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-afac-4196-ab38-4aa0751fecb8', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-29 10:01:00', '2023-07-29 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b0fa-43bb-8ed3-623592632036', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-29 13:00:00', '2023-07-29 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b252-4fe4-8459-af4fe6b81f46', '994cbf1a-add8-4f9f-bab7-60a02e3d9dff', 'AVAILABLE', NULL, '2023-07-29 15:01:00', '2023-07-29 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b4c3-4538-95f1-c3045e40fffc', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-05-31 08:00:00', '2023-05-31 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b53b-43b5-b8e1-0f3c549f3177', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-05-31 10:01:00', '2023-05-31 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b5b0-487a-82f1-3cf8bc885c74', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-05-31 13:00:00', '2023-05-31 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b626-489c-9181-6ac4cf408490', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-05-31 15:01:00', '2023-05-31 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b70a-406e-a9b1-29b4b65f45a9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-01 08:00:00', '2023-06-01 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b783-445b-95ad-f83071538477', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-01 10:01:00', '2023-06-01 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b7fe-40a9-9c61-410ec972614b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-01 13:00:00', '2023-06-01 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b87a-48eb-9757-5d621797c2d6', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-01 15:01:00', '2023-06-01 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b960-4d77-b3bf-4c62e5284c1a', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-02 08:00:00', '2023-06-02 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-b9f1-4dc1-b38b-9724213ce32d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-02 10:01:00', '2023-06-02 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ba81-4e1e-b83b-f762e1ed6ba4', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-02 13:00:00', '2023-06-02 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-bb02-4d0e-8cb5-3fd334837f48', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-02 15:01:00', '2023-06-02 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-bc0c-4596-914d-d722aaeaa40f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-03 08:00:00', '2023-06-03 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-bc90-43ad-bf51-d539f68c2481', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-03 10:01:00', '2023-06-03 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-bd11-4420-ac1b-9a0fcd05e817', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-03 13:00:00', '2023-06-03 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-bd8f-490a-addf-3e0af1089ebc', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-03 15:01:00', '2023-06-03 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-be78-45db-8bed-1ae3eb6359ef', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-04 08:00:00', '2023-06-04 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-bef9-4615-8fff-c0e4d5970522', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-04 10:01:00', '2023-06-04 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-bf7a-4c27-96e1-39c782a6b595', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-04 13:00:00', '2023-06-04 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-bffe-4f32-951d-8f9d65cc5325', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-04 15:01:00', '2023-06-04 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c104-4cfc-8d1f-198cf3f65ab9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-05 08:00:00', '2023-06-05 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c188-4b64-b6eb-64aee5b66614', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-05 10:01:00', '2023-06-05 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c20d-4ff3-91ad-49a0e061c30b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-05 13:00:00', '2023-06-05 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c290-4df7-acd7-133e987ab15d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-05 15:01:00', '2023-06-05 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c37e-484f-821c-d6d3d28cdabf', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-06 08:00:00', '2023-06-06 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c458-47d4-aebb-aa3ca6104a13', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-06 10:01:00', '2023-06-06 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c53a-40d4-ae00-557e44065526', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-06 13:00:00', '2023-06-06 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c61b-4861-9c36-f7b2fcda5e44', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-06 15:01:00', '2023-06-06 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c78c-479a-8fda-772e40da7dd1', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-07 08:00:00', '2023-06-07 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c865-4fd4-a619-1a508ae0727d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-07 10:01:00', '2023-06-07 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-c920-41fb-9fbb-28c074008391', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-07 13:00:00', '2023-06-07 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ca12-48bc-8eac-d7cd43636a2f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-07 15:01:00', '2023-06-07 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-cb32-454f-bc7f-c02936c4c477', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-08 08:00:00', '2023-06-08 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-cbdd-433a-ba7e-ffb7631e35a8', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-08 10:01:00', '2023-06-08 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-cc7e-4230-a4d3-d9c27fb0ae0d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-08 13:00:00', '2023-06-08 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-cd12-47a0-bef4-63f3cc97fbcf', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-08 15:01:00', '2023-06-08 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ce0c-4088-80e7-0a42bae95ab9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-09 08:00:00', '2023-06-09 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-cedd-49c1-8c1f-cb2d5d92cb4b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-09 10:01:00', '2023-06-09 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-cf6d-46a6-991a-9af3e1416ace', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-09 13:00:00', '2023-06-09 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-cffe-4cc8-aaad-588ca501d1b6', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-09 15:01:00', '2023-06-09 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d0ea-477f-9068-dffce21b0b20', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-10 08:00:00', '2023-06-10 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d179-4bdc-abc6-04423e2cb213', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-10 10:01:00', '2023-06-10 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48');
INSERT INTO `studio_events` (`id`, `studio_id`, `status`, `hold_until`, `start_time`, `end_time`, `created_at`, `updated_at`) VALUES
('994cbf1b-d207-487a-8bbd-54d1573d5d8c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-10 13:00:00', '2023-06-10 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d2a3-4da3-99cf-b93d8f9ab083', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-10 15:01:00', '2023-06-10 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d39f-4196-a64b-761edb8db0c9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-11 08:00:00', '2023-06-11 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d42e-4853-b044-eb9c15c0f17a', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-11 10:01:00', '2023-06-11 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d4bd-48c6-a4a2-de229624b1b8', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-11 13:00:00', '2023-06-11 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d54a-4023-ac52-3f36dd5b84fd', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-11 15:01:00', '2023-06-11 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d634-4cd5-9e42-25512db8c355', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-12 08:00:00', '2023-06-12 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d6c4-493e-be03-037c05a889e0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-12 10:01:00', '2023-06-12 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d74e-4a97-a947-fac6b048d6c7', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-12 13:00:00', '2023-06-12 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d7da-4d7f-8cb3-c99aeb94941b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-12 15:01:00', '2023-06-12 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d8c5-45d0-ab8f-1c4796e5fc07', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-13 08:00:00', '2023-06-13 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d956-4e8b-a421-733a1170cd58', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-13 10:01:00', '2023-06-13 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-d9e1-4e13-842f-154079cb4292', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-13 13:00:00', '2023-06-13 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-da6b-48cf-b122-f5815646b33c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-13 15:01:00', '2023-06-13 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-db5b-4ac9-8a50-7d6dedf18ae0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-14 08:00:00', '2023-06-14 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-dbea-4b8c-bcac-1f6a0dfc0c1d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-14 10:01:00', '2023-06-14 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-dc79-47c9-9717-b45005b54dc9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-14 13:00:00', '2023-06-14 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-dd36-4058-9079-8b16329e5ea6', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-14 15:01:00', '2023-06-14 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-de37-468f-ac8a-5fe950cbbd10', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-15 08:00:00', '2023-06-15 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ded0-4aba-bc88-098f8456ed5c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-15 10:01:00', '2023-06-15 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-df6d-4173-b115-02f2b810c723', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-15 13:00:00', '2023-06-15 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-e0a4-45ad-a3c6-3242f60fcb01', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-15 15:01:00', '2023-06-15 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-e262-40e6-bd2f-4d0b8097ddc7', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-16 08:00:00', '2023-06-16 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-e395-4396-bf34-6fb501cd6216', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-16 10:01:00', '2023-06-16 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-e49a-4b26-8992-7a21def7a272', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-16 13:00:00', '2023-06-16 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-e573-4a79-8391-19791be37fc8', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-16 15:01:00', '2023-06-16 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-e777-49a8-a3e9-45f5a83c1e91', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-17 08:00:00', '2023-06-17 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-e907-43ec-8995-4b8b2ff7aa1d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-17 10:01:00', '2023-06-17 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ea40-443d-b46d-34b5c13f7020', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-17 13:00:00', '2023-06-17 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-eb5e-45ef-8546-cd4ff0e352e2', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-17 15:01:00', '2023-06-17 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ed4b-41d2-bd11-bd05f9b7b9d1', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-18 08:00:00', '2023-06-18 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ee83-4d86-bf24-1cfc91f7005f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-18 10:01:00', '2023-06-18 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-ef86-4275-a1a8-111bee59bd12', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-18 13:00:00', '2023-06-18 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-f0b8-4f8a-90ee-0c6c73fed87b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-18 15:01:00', '2023-06-18 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-f2c7-4d3b-86e5-0d3c74e36aba', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-19 08:00:00', '2023-06-19 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-f3ea-4304-9b38-63390bfc7f71', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-19 10:01:00', '2023-06-19 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-f501-4bc7-85e5-2702363a8781', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-19 13:00:00', '2023-06-19 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-f62d-4b52-8d28-de1e3d16de4b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-19 15:01:00', '2023-06-19 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-f7c7-4be6-ae77-b28680b1887b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-20 08:00:00', '2023-06-20 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-f8da-4e34-9f33-5e329d641da9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-20 10:01:00', '2023-06-20 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-f9b4-4dff-b217-89d865ddae3f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-20 13:00:00', '2023-06-20 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-fa6a-4399-ac28-70aa8f5672c0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-20 15:01:00', '2023-06-20 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-fbc7-4be8-8ef7-3faa41aa2177', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-21 08:00:00', '2023-06-21 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-fccd-4590-a474-6c321d42cb14', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-21 10:01:00', '2023-06-21 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-fdca-469c-820c-6726ce0cb0f6', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-21 13:00:00', '2023-06-21 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1b-fecd-4a1e-a0da-fc9e290ab0d8', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-21 15:01:00', '2023-06-21 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-0087-476c-a899-36bc75e29be0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-22 08:00:00', '2023-06-22 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-01a9-4b05-a5cc-99d9e7bbdd3f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-22 10:01:00', '2023-06-22 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-029e-454f-89f1-fd92fddd40da', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-22 13:00:00', '2023-06-22 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-038e-49b6-a2ee-b06eb5de70dd', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-22 15:01:00', '2023-06-22 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-04dc-46c6-bf3b-5c78885cbbf4', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-23 08:00:00', '2023-06-23 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-05ec-4dca-bb9c-9e5ae2dd0335', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-23 10:01:00', '2023-06-23 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-06a8-4b04-8e55-3aa643d6e1ca', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-23 13:00:00', '2023-06-23 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-077a-479b-8ebc-607f8921b70c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-23 15:01:00', '2023-06-23 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-089f-491c-b723-1bb3b718e3c9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-24 08:00:00', '2023-06-24 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-0958-4bbe-8a6d-aaf419e7befb', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-24 10:01:00', '2023-06-24 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-0a16-49cc-9cff-bd0c212aa955', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-24 13:00:00', '2023-06-24 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-0ad7-4460-8b80-ec8d49c66529', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-24 15:01:00', '2023-06-24 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-0bf5-4ac3-8f8a-fb563834d198', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-25 08:00:00', '2023-06-25 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-0cf0-4dd9-bef9-3c5b2468a4ab', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-25 10:01:00', '2023-06-25 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-0e40-499e-aba7-58de38f43b3d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-25 13:00:00', '2023-06-25 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-0f54-4fcb-9386-bf94d968679e', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-25 15:01:00', '2023-06-25 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-10d8-43a3-8657-196423be2031', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-26 08:00:00', '2023-06-26 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-119e-4833-8b68-690793b652df', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-26 10:01:00', '2023-06-26 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1297-4d1d-9fc8-4f9b3f7d0be6', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-26 13:00:00', '2023-06-26 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-13ce-4dd3-a495-528fae94509f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-26 15:01:00', '2023-06-26 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-157b-4799-a52d-42704aee4005', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-27 08:00:00', '2023-06-27 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1695-4d88-a3ed-8739865fa347', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-27 10:01:00', '2023-06-27 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1781-477e-b102-85b36cc2466b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-27 13:00:00', '2023-06-27 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1872-4dc8-81c8-a653d746bfb2', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-27 15:01:00', '2023-06-27 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-19df-42c5-b8c9-bb17c1232304', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-28 08:00:00', '2023-06-28 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1ab3-4d14-92e3-5e3fbed4eae9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-28 10:01:00', '2023-06-28 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1b9e-456f-b044-f936494e8031', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-28 13:00:00', '2023-06-28 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1cb1-409c-ae1f-66a8b03e55c6', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-28 15:01:00', '2023-06-28 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1e26-4a1d-8258-2ee354f36e8a', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-29 08:00:00', '2023-06-29 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1eee-43c9-af0b-0c9fd5bba7bf', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-29 10:01:00', '2023-06-29 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-1ffd-4ac8-a2e7-aff4dd6d4aa0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-29 13:00:00', '2023-06-29 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-20c2-4bd6-839c-48f64854ce72', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-29 15:01:00', '2023-06-29 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-225a-495f-91cf-1aa7de5d6d0f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-30 08:00:00', '2023-06-30 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-238b-423b-9d0b-d40e469680e8', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-30 10:01:00', '2023-06-30 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-24a8-478d-a24c-ade31c704292', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-30 13:00:00', '2023-06-30 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-25c5-4ee4-b26d-1c88447350b0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-06-30 15:01:00', '2023-06-30 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-2721-4fe3-803b-856aff802697', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-01 08:00:00', '2023-07-01 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-2823-4d16-8c34-e28494bc8294', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-01 10:01:00', '2023-07-01 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-28fe-4c7b-98f5-2da68291f89a', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-01 13:00:00', '2023-07-01 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-2a10-4e7d-b999-5eba942866e9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-01 15:01:00', '2023-07-01 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-2c46-4b1a-8c6a-5ec6d3fe04e7', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-02 08:00:00', '2023-07-02 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-2dba-4e07-8467-8768a6546661', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-02 10:01:00', '2023-07-02 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-2ef2-4159-bdaa-40d3b03612ef', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-02 13:00:00', '2023-07-02 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-2feb-46ef-9396-b258de4a4a5b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-02 15:01:00', '2023-07-02 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3173-4622-bcfe-55ae9427b21a', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-03 08:00:00', '2023-07-03 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-326f-4a3f-99f1-c079dc42023f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-03 10:01:00', '2023-07-03 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-338f-4dcf-9a90-729017c776b1', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-03 13:00:00', '2023-07-03 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3489-4cb4-a5c7-100649dd0664', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-03 15:01:00', '2023-07-03 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-35f9-488d-a147-02ac2b777333', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-04 08:00:00', '2023-07-04 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-36e0-4319-9135-0dd8c9a58a09', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-04 10:01:00', '2023-07-04 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-37bd-42be-a00a-0995e7294fdd', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-04 13:00:00', '2023-07-04 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3894-4cef-b78f-8b8a960b5e95', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-04 15:01:00', '2023-07-04 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3a12-4396-88ad-64a352c21d7e', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-05 08:00:00', '2023-07-05 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3ae6-49f9-bfd9-84ecfc12122c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-05 10:01:00', '2023-07-05 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3bb9-4a82-83f0-2a2c8c2142cc', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-05 13:00:00', '2023-07-05 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3c8e-4468-bb90-6f5b3ac25b24', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-05 15:01:00', '2023-07-05 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3dc8-4f3a-9e6f-7390621da9d6', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-06 08:00:00', '2023-07-06 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3ea3-4909-9cf9-25019be25bc5', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-06 10:01:00', '2023-07-06 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-3f75-4a5b-9780-9743038ec13e', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-06 13:00:00', '2023-07-06 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4049-4aec-8ad5-f7ff50161462', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-06 15:01:00', '2023-07-06 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4187-4df0-a27e-3a64d678e6ea', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-07 08:00:00', '2023-07-07 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-425e-42d2-8b2b-c62349bc3045', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-07 10:01:00', '2023-07-07 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4333-4b83-8e96-37f91f515750', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-07 13:00:00', '2023-07-07 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-440c-4b78-a6a1-36b5bb1b0ea5', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-07 15:01:00', '2023-07-07 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-454d-42fc-accb-33622350b647', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-08 08:00:00', '2023-07-08 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4624-4e92-9357-46652243cb70', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-08 10:01:00', '2023-07-08 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-46fc-4944-a424-c7d3332707b4', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-08 13:00:00', '2023-07-08 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-47d4-41d1-87c3-64b008fa0ce8', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-08 15:01:00', '2023-07-08 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-493e-41dc-81e6-4df7278654bc', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-09 08:00:00', '2023-07-09 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4a23-41b6-8552-3cccf86e8e79', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-09 10:01:00', '2023-07-09 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4b0c-48ef-9bfe-ecdd53dd0f96', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-09 13:00:00', '2023-07-09 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4bf7-4bdc-b1ae-0e68565bfcaf', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-09 15:01:00', '2023-07-09 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4d55-4693-8e97-a60aa6a937d5', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-10 08:00:00', '2023-07-10 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4e4c-4a5a-9e84-130573ddec2d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-10 10:01:00', '2023-07-10 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-4f3b-4b8d-9f78-36089d8cb499', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-10 13:00:00', '2023-07-10 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5029-40d3-805e-b2820de7dd45', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-10 15:01:00', '2023-07-10 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-518d-49cd-9934-028d22073524', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-11 08:00:00', '2023-07-11 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5281-4c1e-8c6c-f8a3d8255aab', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-11 10:01:00', '2023-07-11 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5371-42d3-a181-b18d61be173b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-11 13:00:00', '2023-07-11 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5463-4bff-8e80-7b8423a8aadd', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-11 15:01:00', '2023-07-11 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-55ee-40bc-ac0c-346c1b7226e0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-12 08:00:00', '2023-07-12 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5722-4288-9325-8adb021b0500', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-12 10:01:00', '2023-07-12 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5852-4e2e-9644-781f4cac31d4', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-12 13:00:00', '2023-07-12 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5951-44b6-b23e-54f530ad7042', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-12 15:01:00', '2023-07-12 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5abd-4be5-bbc4-01502cdee724', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-13 08:00:00', '2023-07-13 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5bb3-4c17-9c37-5d16459e1c7c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-13 10:01:00', '2023-07-13 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5cae-459a-8c2f-e102e6555d54', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-13 13:00:00', '2023-07-13 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5da3-4135-919e-2680adb3ff86', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-13 15:01:00', '2023-07-13 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-5f16-4fd8-b4c6-4e1e77e67ef9', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-14 08:00:00', '2023-07-14 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6017-4fd3-be4f-50d28aa40214', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-14 10:01:00', '2023-07-14 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6118-4dd0-97e5-f10e2c4fab89', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-14 13:00:00', '2023-07-14 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6219-498e-9154-65d9fb40926e', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-14 15:01:00', '2023-07-14 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-637c-496c-91b0-4c3ca771e353', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-15 08:00:00', '2023-07-15 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6477-48dc-92e8-bdc213220e82', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-15 10:01:00', '2023-07-15 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-656b-4596-afee-1909e539a624', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-15 13:00:00', '2023-07-15 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6662-4fc8-863f-7a4960298ee8', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-15 15:01:00', '2023-07-15 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-67ce-4e8d-870d-4651a38351a0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-16 08:00:00', '2023-07-16 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-68ee-4d6f-8770-5a121a4a954c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-16 10:01:00', '2023-07-16 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-69f8-4972-b7d0-d986e26271bc', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-16 13:00:00', '2023-07-16 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6b05-4992-b225-001d53e9a674', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-16 15:01:00', '2023-07-16 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6c87-4ab7-b240-c9b27d3a1858', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-17 08:00:00', '2023-07-17 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6d95-4d17-a010-e16921f46cb2', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-17 10:01:00', '2023-07-17 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6eae-4964-98ce-fcbb9d2ae17f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-17 13:00:00', '2023-07-17 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-6fc1-4b8d-a55d-d7972507b6df', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-17 15:01:00', '2023-07-17 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-713e-40d0-80ba-654553886596', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-18 08:00:00', '2023-07-18 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-724e-4196-bc2b-1b77c8bcd6ca', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-18 10:01:00', '2023-07-18 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-7360-488e-a226-9e4ee12b4f52', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-18 13:00:00', '2023-07-18 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-7472-4d52-8057-697d8be03e56', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-18 15:01:00', '2023-07-18 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-75fd-4a58-8245-86c11e44e0b7', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-19 08:00:00', '2023-07-19 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-770a-4716-86ee-1df95651b41d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-19 10:01:00', '2023-07-19 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-7835-469b-ab9f-155b958c0938', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-19 13:00:00', '2023-07-19 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-7948-4a2c-a1b8-794c6ad590ea', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-19 15:01:00', '2023-07-19 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-7aff-41fd-90cf-cd796947975e', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-20 08:00:00', '2023-07-20 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-7c40-484e-82e9-6fa70fdbdcd4', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-20 10:01:00', '2023-07-20 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-7db5-4d99-911c-a5b80bacacfb', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-20 13:00:00', '2023-07-20 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-7f0d-4533-88b8-6152cc13ecb0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-20 15:01:00', '2023-07-20 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-80bd-49d2-8ede-93ce4277939c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-21 08:00:00', '2023-07-21 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-81ec-440c-a847-8625d5d33c29', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-21 10:01:00', '2023-07-21 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-830f-45db-8f53-a732f9b9009c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-21 13:00:00', '2023-07-21 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-8434-4b65-aa1b-23a4d0494b59', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-21 15:01:00', '2023-07-21 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-85cf-4e7a-9476-c14f9aaa5d00', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-22 08:00:00', '2023-07-22 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-86fb-4bc9-aafe-332eeee6a65e', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-22 10:01:00', '2023-07-22 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-8825-443b-9131-c7915d403bb2', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-22 13:00:00', '2023-07-22 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-8953-476a-9bf8-b6fa17305435', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-22 15:01:00', '2023-07-22 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-8bb7-4930-af02-5c8eedb204e1', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-23 08:00:00', '2023-07-23 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-8d71-456d-876b-4802b3acde36', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-23 10:01:00', '2023-07-23 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-8ef6-49e2-8a20-5dc740ffc26e', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-23 13:00:00', '2023-07-23 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-9083-45b9-b8b6-f4146d74f843', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-23 15:01:00', '2023-07-23 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-9293-4830-a248-b586fff1955f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-24 08:00:00', '2023-07-24 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-9407-43a6-828c-a67e522a305a', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-24 10:01:00', '2023-07-24 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-95a9-43e7-9f47-597f8bd859ee', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-24 13:00:00', '2023-07-24 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-9737-42d3-afea-3051a49a98a3', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-24 15:01:00', '2023-07-24 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-994a-4068-a815-23d0653e75bb', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-25 08:00:00', '2023-07-25 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-9ac7-4c1b-9b96-e2c4c397fbcd', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-25 10:01:00', '2023-07-25 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-9c55-4a33-8bf7-d881759d1532', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-25 13:00:00', '2023-07-25 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-9dcc-46f6-9e98-53c6f7cc5b05', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-25 15:01:00', '2023-07-25 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-9fd2-4651-a203-f4a8f7d6c89c', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-26 08:00:00', '2023-07-26 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-a12d-40c8-bdf5-f1a44c1074a8', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-26 10:01:00', '2023-07-26 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-a26f-4645-8901-f972016b8511', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-26 13:00:00', '2023-07-26 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-a3f7-4a4a-9d89-67a41b73203b', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-26 15:01:00', '2023-07-26 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-a698-48d1-b3dc-779f5968c6de', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-27 08:00:00', '2023-07-27 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-a853-4a82-84c9-038c9e9f23b3', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-27 10:01:00', '2023-07-27 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-a9e4-418b-afa6-d2c230fa0439', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-27 13:00:00', '2023-07-27 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-ab71-462d-9edd-a7e774c55686', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-27 15:01:00', '2023-07-27 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-ad9c-40e3-baad-52a86d05369d', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-28 08:00:00', '2023-07-28 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-af13-4787-9d85-dffdccf09c96', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-28 10:01:00', '2023-07-28 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-b090-4f2a-8bbb-183b47418af0', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-28 13:00:00', '2023-07-28 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-b2e7-4122-803d-a8e686a5b730', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-28 15:01:00', '2023-07-28 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-b63c-40f7-ac5f-d28d40901d11', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-29 08:00:00', '2023-07-29 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-b8c4-46a6-b95f-626b09a4b864', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-29 10:01:00', '2023-07-29 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-ba65-49d5-a5d4-8fe441cd8358', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-29 13:00:00', '2023-07-29 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-bbf6-404d-bcd0-93d16a398a7f', '994cbf1b-b2ed-4d63-88c6-08bdc35fc860', 'AVAILABLE', NULL, '2023-07-29 15:01:00', '2023-07-29 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-bf35-4f30-a730-68b40c7c1d4d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-05-31 08:00:00', '2023-05-31 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-bfec-4faa-bfc2-107dbac23111', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-05-31 10:01:00', '2023-05-31 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c087-413c-b68c-12a07d5e2df1', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-05-31 13:00:00', '2023-05-31 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c109-4263-824a-16d8382c8902', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-05-31 15:01:00', '2023-05-31 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c204-49e6-95a3-d223e31af503', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-01 08:00:00', '2023-06-01 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c288-43ef-9590-c190edb8644d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-01 10:01:00', '2023-06-01 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c30f-4d89-a497-7d290ff0ee2c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-01 13:00:00', '2023-06-01 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c393-41c7-91dd-252e811dc11f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-01 15:01:00', '2023-06-01 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c481-4299-94dd-667d89a033e6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-02 08:00:00', '2023-06-02 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c502-4772-bd65-e2b1e7049207', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-02 10:01:00', '2023-06-02 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c588-40ff-9109-2a5951e13b4b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-02 13:00:00', '2023-06-02 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c60d-4a5b-9d0e-b6a8ca559bf6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-02 15:01:00', '2023-06-02 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c6fa-49f6-bbe5-fa4feb87c38e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-03 08:00:00', '2023-06-03 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c785-4031-b648-59fd7a16a92b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-03 10:01:00', '2023-06-03 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c810-40d1-b509-9c6495b61321', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-03 13:00:00', '2023-06-03 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c891-4eb0-8ad8-7d560a6fb1ac', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-03 15:01:00', '2023-06-03 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c978-43f1-9c6d-25a786fccb07', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-04 08:00:00', '2023-06-04 10:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-c9fb-416a-8ed9-c51d518d934b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-04 10:01:00', '2023-06-04 12:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-cac1-4888-90b4-ce28302402a7', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-04 13:00:00', '2023-06-04 15:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-cbc1-4d6f-88a0-a707486c1a5d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-04 15:01:00', '2023-06-04 18:00:00', '2023-05-31 16:03:48', '2023-05-31 16:03:48'),
('994cbf1c-cd54-4eb9-b03f-e247ac328911', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-05 08:00:00', '2023-06-05 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-ce45-4ad7-89ee-cc8d6e98962b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-05 10:01:00', '2023-06-05 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-cf2c-4c1e-b66c-7c575f9a3275', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-05 13:00:00', '2023-06-05 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d01d-462f-af45-5341906d380d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-05 15:01:00', '2023-06-05 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d1a3-4d1a-b9e8-6dce8b20c431', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-06 08:00:00', '2023-06-06 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d272-4ef3-9746-ca87ce0d2916', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-06 10:01:00', '2023-06-06 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d34c-4b32-9aeb-096e216050b1', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-06 13:00:00', '2023-06-06 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d41d-469f-b874-83e85eb1d0fe', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-06 15:01:00', '2023-06-06 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d5a8-4991-94d2-1258e9cf0694', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-07 08:00:00', '2023-06-07 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d681-4f50-b923-6acdac72a6f6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-07 10:01:00', '2023-06-07 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d759-42c0-8708-e0aa401bd40b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-07 13:00:00', '2023-06-07 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d837-4a53-8a8a-9c6d9b41d7e6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-07 15:01:00', '2023-06-07 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-d9cc-4744-a856-040e1eab92d7', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-08 08:00:00', '2023-06-08 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-daad-4d8a-9896-813a704367c8', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-08 10:01:00', '2023-06-08 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-db90-4eac-85c9-09df05de2961', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-08 13:00:00', '2023-06-08 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-dce8-4a58-8542-e702f5b6e747', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-08 15:01:00', '2023-06-08 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-df8a-404e-a681-1a679b00e298', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-09 08:00:00', '2023-06-09 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-e0e5-479b-a18e-405a2377aef7', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-09 10:01:00', '2023-06-09 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-e234-453c-a37a-b6d43880bae3', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-09 13:00:00', '2023-06-09 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-e3be-4f39-b866-f9406333785e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-09 15:01:00', '2023-06-09 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-e666-4352-be57-de0f4e1c5101', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-10 08:00:00', '2023-06-10 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-e7c1-4bb3-90b9-9183e4e16122', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-10 10:01:00', '2023-06-10 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-e8d2-4e84-91a8-4ba833320add', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-10 13:00:00', '2023-06-10 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-e9d4-40f9-9474-4718237bd128', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-10 15:01:00', '2023-06-10 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-eb97-47e2-b2e5-aec5802183c8', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-11 08:00:00', '2023-06-11 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-ecea-4617-9f37-f68b7d8ba17d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-11 10:01:00', '2023-06-11 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-ee34-439d-98a2-b39ba0abfd7d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-11 13:00:00', '2023-06-11 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-efa9-49f6-b9f8-702c13b089f8', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-11 15:01:00', '2023-06-11 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-f24a-4cf5-a4ca-93029ed7f0b6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-12 08:00:00', '2023-06-12 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-f400-4ddf-ad19-547b1e25da07', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-12 10:01:00', '2023-06-12 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-f52a-4f23-accd-9a00657850c0', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-12 13:00:00', '2023-06-12 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-f63b-4af9-a7e9-725f7f686c54', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-12 15:01:00', '2023-06-12 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-f7db-46eb-a4d0-d0ead2c8c727', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-13 08:00:00', '2023-06-13 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-f8c3-474e-a64b-bc84eaebec56', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-13 10:01:00', '2023-06-13 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-f9a7-4b49-8199-c48fe9296311', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-13 13:00:00', '2023-06-13 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-fa91-4180-bb75-37932b07b443', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-13 15:01:00', '2023-06-13 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-fc54-46a0-a32f-95749090447c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-14 08:00:00', '2023-06-14 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-fd3f-4727-9e34-10d51a0b653f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-14 10:01:00', '2023-06-14 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-fe28-411b-a5b3-588ff08f76da', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-14 13:00:00', '2023-06-14 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1c-ff17-438e-87fb-bbc85f808f6f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-14 15:01:00', '2023-06-14 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0086-4009-be1b-37cdce8042a0', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-15 08:00:00', '2023-06-15 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0160-4e5a-812f-e38108f255a7', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-15 10:01:00', '2023-06-15 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0241-45dc-9aa8-81a4dae5a616', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-15 13:00:00', '2023-06-15 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49');
INSERT INTO `studio_events` (`id`, `studio_id`, `status`, `hold_until`, `start_time`, `end_time`, `created_at`, `updated_at`) VALUES
('994cbf1d-0319-4c29-9794-5dd07b11cb26', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-15 15:01:00', '2023-06-15 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0493-45cc-84cd-198883a00c44', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-16 08:00:00', '2023-06-16 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0564-42b3-9ce0-1993772acb96', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-16 10:01:00', '2023-06-16 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-063d-49ae-8a6c-91f37890a00f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-16 13:00:00', '2023-06-16 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0722-4057-afa5-bf485d9a82d6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-16 15:01:00', '2023-06-16 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-08aa-4606-89fa-268dd0ba1af6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-17 08:00:00', '2023-06-17 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0985-473c-9d6a-d1a4a647bd16', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-17 10:01:00', '2023-06-17 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0a61-4ded-ab99-d86c82f5f849', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-17 13:00:00', '2023-06-17 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0b49-4930-ba2a-563e7ef0cbb7', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-17 15:01:00', '2023-06-17 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0cc9-4a3f-a941-71f2afc332cc', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-18 08:00:00', '2023-06-18 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0db1-4db9-833f-e05a835e3931', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-18 10:01:00', '2023-06-18 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0e9f-45ec-9f1c-2f846368f84f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-18 13:00:00', '2023-06-18 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-0f8d-439c-ab7e-599e0aad500c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-18 15:01:00', '2023-06-18 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-1106-4950-876d-cb499543814b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-19 08:00:00', '2023-06-19 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-11d1-4a6c-a706-f4d4c0e0cad8', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-19 10:01:00', '2023-06-19 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-12ac-4737-8684-88f27e0d4f86', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-19 13:00:00', '2023-06-19 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-138e-4a0a-b682-2df66d8e77f3', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-19 15:01:00', '2023-06-19 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-14fd-4425-8431-a5d4724efe19', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-20 08:00:00', '2023-06-20 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-15df-44f3-b46f-ade8640d7faf', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-20 10:01:00', '2023-06-20 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-175e-4028-b343-ea0e8398d97a', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-20 13:00:00', '2023-06-20 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-1920-401b-8798-b2bb1caac66b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-20 15:01:00', '2023-06-20 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-1ba2-4868-980c-b48872651b16', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-21 08:00:00', '2023-06-21 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-1cde-4697-946f-5882ac20d68e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-21 10:01:00', '2023-06-21 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-1e19-4eb1-b3b1-2ee95c2aef21', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-21 13:00:00', '2023-06-21 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-1f38-43bc-a8fe-25404c398521', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-21 15:01:00', '2023-06-21 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-20ca-4700-bf10-bb5d883943f0', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-22 08:00:00', '2023-06-22 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-21c4-4b3d-a664-2b646e8971c4', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-22 10:01:00', '2023-06-22 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-22be-41f0-a659-67484086e3af', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-22 13:00:00', '2023-06-22 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-23ad-4ddb-9f96-1de59a4ec703', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-22 15:01:00', '2023-06-22 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-253a-498a-bb57-871ddea2fd17', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-23 08:00:00', '2023-06-23 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-262e-4147-891d-7b7fb171b0b1', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-23 10:01:00', '2023-06-23 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-2727-486d-a00a-a9235fec46ea', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-23 13:00:00', '2023-06-23 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-281c-497a-bb42-16e1275df31b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-23 15:01:00', '2023-06-23 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-29ac-4f1d-ada4-0a90bbeadc0e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-24 08:00:00', '2023-06-24 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-2aa6-4b56-817b-62d4b4033a66', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-24 10:01:00', '2023-06-24 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-2ba0-4a13-98ed-3dc3c26e31ba', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-24 13:00:00', '2023-06-24 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-2c96-4325-b7f9-a78cc664d2e0', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-24 15:01:00', '2023-06-24 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-2e27-4ba5-bf56-4b9d2e023a8e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-25 08:00:00', '2023-06-25 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-2fef-417d-bda9-6016e52ddcd9', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-25 10:01:00', '2023-06-25 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-30ec-4a45-be32-607894be38b7', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-25 13:00:00', '2023-06-25 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-3216-416a-a370-f814b9aaf33c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-25 15:01:00', '2023-06-25 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-3454-4cec-b0a0-50b8ae2ceba6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-26 08:00:00', '2023-06-26 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-35e7-42ec-ac42-013058ec1958', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-26 10:01:00', '2023-06-26 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-3709-48ca-98ab-79e6c3bd40aa', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-26 13:00:00', '2023-06-26 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-381c-4a68-8a4e-1b07e779d409', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-26 15:01:00', '2023-06-26 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-3a10-42c7-8d5f-7bc44c9581ce', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-27 08:00:00', '2023-06-27 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-3bf2-4ce6-a3f7-ced6ddd1ee2a', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-27 10:01:00', '2023-06-27 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-3dcd-49ee-8540-73726ea15091', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-27 13:00:00', '2023-06-27 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-3f15-4fcc-97a4-85caf151f83c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-27 15:01:00', '2023-06-27 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-4168-4e81-a347-e040cb2447dd', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-28 08:00:00', '2023-06-28 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-4323-44e9-ab1f-105ddf1015d8', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-28 10:01:00', '2023-06-28 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-4482-4f98-8d38-2fe6599b2b19', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-28 13:00:00', '2023-06-28 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-463b-4510-b5f8-0d0cb6893315', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-28 15:01:00', '2023-06-28 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-4859-4b34-bb11-0b0b70f2433d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-29 08:00:00', '2023-06-29 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-49f6-4e07-9124-2e506255fe5d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-29 10:01:00', '2023-06-29 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-4bf2-440e-a670-507f2bcf4b00', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-29 13:00:00', '2023-06-29 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-4e24-4681-b8ee-e4d1340ef41e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-29 15:01:00', '2023-06-29 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-50be-4ace-b390-96c818fd5e5c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-30 08:00:00', '2023-06-30 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-523b-4565-8cbe-4a656086a4db', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-30 10:01:00', '2023-06-30 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-5374-430a-a6dc-9298a25a8d6c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-30 13:00:00', '2023-06-30 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-54b4-48e4-acda-97b3f316e50f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-06-30 15:01:00', '2023-06-30 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-566e-4c74-917f-935277071ffc', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-01 08:00:00', '2023-07-01 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-5764-4559-a218-2e38d98732d1', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-01 10:01:00', '2023-07-01 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-5856-4bd7-b5f9-cb6b1476c372', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-01 13:00:00', '2023-07-01 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-59eb-45bf-8a45-620ecb229ff8', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-01 15:01:00', '2023-07-01 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-5c79-4915-9690-45ab7b16e404', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-02 08:00:00', '2023-07-02 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-5e3b-4879-95db-0815f3c1f5b0', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-02 10:01:00', '2023-07-02 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-5f8b-4a66-840d-be015b4b0f4e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-02 13:00:00', '2023-07-02 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-616e-44f0-9c14-0fa8f921a808', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-02 15:01:00', '2023-07-02 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-6497-4783-a208-d2020c5dcf26', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-03 08:00:00', '2023-07-03 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-6671-49b1-b6c2-ed419092b13d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-03 10:01:00', '2023-07-03 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-68c7-4ff9-986f-b1cea8d0fb40', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-03 13:00:00', '2023-07-03 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-6ab4-4590-b149-14849bbd46ad', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-03 15:01:00', '2023-07-03 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-6d1f-4266-9245-6007e6cbc5c9', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-04 08:00:00', '2023-07-04 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-6e82-4234-a941-300fb1bd6c0b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-04 10:01:00', '2023-07-04 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-6fd0-478e-9425-3dfafae2bda3', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-04 13:00:00', '2023-07-04 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-711f-4736-95fb-5e0a71a99832', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-04 15:01:00', '2023-07-04 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-72f6-4fe6-94cc-76ff1e723f91', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-05 08:00:00', '2023-07-05 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-741e-4241-8226-760fc398830b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-05 10:01:00', '2023-07-05 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-753e-47b2-a6e5-6d025e1c7583', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-05 13:00:00', '2023-07-05 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-765c-4508-9ede-346c7f1c355e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-05 15:01:00', '2023-07-05 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-7817-4d61-87e1-5bec33fe2396', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-06 08:00:00', '2023-07-06 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-793d-4f67-9359-756db0030d20', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-06 10:01:00', '2023-07-06 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-7a5f-4932-96c3-56487868a34e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-06 13:00:00', '2023-07-06 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-7b80-46f4-80be-9162cac9455a', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-06 15:01:00', '2023-07-06 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-7e77-4509-92a7-8722bbbcaf29', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-07 08:00:00', '2023-07-07 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-80e9-4f1a-b866-acdb901a21b2', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-07 10:01:00', '2023-07-07 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-82de-4654-84db-193a116d0cd8', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-07 13:00:00', '2023-07-07 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-8479-4a32-94ab-bc48904614c5', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-07 15:01:00', '2023-07-07 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-8642-4425-9f3c-6c5a0072f89c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-08 08:00:00', '2023-07-08 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-876c-46e2-a9ef-b15b2a325fc3', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-08 10:01:00', '2023-07-08 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-8890-4098-b029-6d1f0735e3db', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-08 13:00:00', '2023-07-08 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-89ba-4f17-9c9a-e48c125aef48', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-08 15:01:00', '2023-07-08 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-8bb3-4073-8d23-a6c9d50e2d06', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-09 08:00:00', '2023-07-09 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-8d65-442a-b78d-5aa695659682', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-09 10:01:00', '2023-07-09 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-8f5f-4b81-949b-9e32467661db', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-09 13:00:00', '2023-07-09 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-90d1-4bc8-9d06-00d27ed7f3e0', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-09 15:01:00', '2023-07-09 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-929d-47a4-932b-5e9f631150fb', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-10 08:00:00', '2023-07-10 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-93b2-499d-86cf-e754bd64d810', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-10 10:01:00', '2023-07-10 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-94c7-42c6-8d31-c8e14cdf044e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-10 13:00:00', '2023-07-10 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-95d7-47a9-8d39-3e4725b93411', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-10 15:01:00', '2023-07-10 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-9768-486d-8cec-44d2a8372054', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-11 08:00:00', '2023-07-11 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-9876-4fab-810d-9836a78c65a3', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-11 10:01:00', '2023-07-11 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-9987-453e-ab43-663e2d423c8b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-11 13:00:00', '2023-07-11 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-9a94-4ae6-b375-bc21c01aff44', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-11 15:01:00', '2023-07-11 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-9c23-4811-99ea-23824c6afa45', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-12 08:00:00', '2023-07-12 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-9d35-44de-9fd9-2bcf6cfe058e', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-12 10:01:00', '2023-07-12 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-9e48-4caa-b1b5-36f912014017', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-12 13:00:00', '2023-07-12 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-9f5c-476f-9250-f518636cca79', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-12 15:01:00', '2023-07-12 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-a0fa-4678-a108-6fc1f5e0224b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-13 08:00:00', '2023-07-13 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-a212-4c8e-8a4b-9e6c03534043', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-13 10:01:00', '2023-07-13 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-a32d-4e6c-b3d8-f061181635bf', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-13 13:00:00', '2023-07-13 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-a443-4a0a-a78b-d397d7cb25e6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-13 15:01:00', '2023-07-13 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-a5da-4bb5-80c7-94ef25bdada5', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-14 08:00:00', '2023-07-14 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-a6f9-42fe-a077-637d245ad824', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-14 10:01:00', '2023-07-14 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-a8a3-47b5-9464-872eccbbe570', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-14 13:00:00', '2023-07-14 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-aaec-44a2-897d-b2b30979b08f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-14 15:01:00', '2023-07-14 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-ad5c-46de-8ab8-28c65a143487', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-15 08:00:00', '2023-07-15 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-aece-4916-abfa-3ceb66212f35', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-15 10:01:00', '2023-07-15 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-b038-434c-9614-89e21922cedd', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-15 13:00:00', '2023-07-15 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-b140-48a9-8c50-2c58cbbf220d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-15 15:01:00', '2023-07-15 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-b2d0-4122-a652-12e82e8abf02', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-16 08:00:00', '2023-07-16 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-b3e1-4410-88a0-c983ef916e08', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-16 10:01:00', '2023-07-16 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-b56c-4c5e-afc6-e3ef99d95a84', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-16 13:00:00', '2023-07-16 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-b740-4195-a41b-c48e38538494', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-16 15:01:00', '2023-07-16 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-b971-4d48-b617-6c63bc007923', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-17 08:00:00', '2023-07-17 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-ba81-4dee-942d-9b9c6564056f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-17 10:01:00', '2023-07-17 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-bb8b-48fc-937a-0526dd93332f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-17 13:00:00', '2023-07-17 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-bd5e-4d08-a3da-b338cabc3e24', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-17 15:01:00', '2023-07-17 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-c02f-48ac-b103-2159f21f33ad', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-18 08:00:00', '2023-07-18 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-c1e5-48b8-92ba-bc2584b01738', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-18 10:01:00', '2023-07-18 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-c38e-4356-8d22-f06807b87d22', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-18 13:00:00', '2023-07-18 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-c61a-4768-86a9-9236b404a2af', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-18 15:01:00', '2023-07-18 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-c867-4570-822f-d4bc517892d6', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-19 08:00:00', '2023-07-19 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-ca66-488a-a73b-a8a7a893e6f2', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-19 10:01:00', '2023-07-19 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-cc6b-4ae8-922d-1db1c8b34039', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-19 13:00:00', '2023-07-19 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-ce43-42d2-b397-9f2c27004360', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-19 15:01:00', '2023-07-19 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-d05e-4028-b53a-cdecfdce45af', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-20 08:00:00', '2023-07-20 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-d1a0-4959-b8e8-096fbf05bd0c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-20 10:01:00', '2023-07-20 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-d30f-4c29-842e-a761a632601d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-20 13:00:00', '2023-07-20 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-d45c-40cf-a096-39a028b7b24d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-20 15:01:00', '2023-07-20 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-d632-4178-b231-1d82627c41fd', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-21 08:00:00', '2023-07-21 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-d76b-49ea-a772-74b6d7b84ca0', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-21 10:01:00', '2023-07-21 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-d89b-4eb4-a87a-ccf1ec757857', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-21 13:00:00', '2023-07-21 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-d9c1-46d5-9538-cd5ae473bb3d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-21 15:01:00', '2023-07-21 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-db6a-4f30-89fd-4a92eb0d30d8', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-22 08:00:00', '2023-07-22 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-dc96-4f50-bb8d-3c50cc75e6a5', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-22 10:01:00', '2023-07-22 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-ddcd-46d4-b8e2-3f5c23f8c689', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-22 13:00:00', '2023-07-22 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-df09-44af-8f30-d530ee4db742', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-22 15:01:00', '2023-07-22 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-e0c0-49a4-b003-b663e08cda7a', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-23 08:00:00', '2023-07-23 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-e209-4c45-bc85-e1327ba50b3c', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-23 10:01:00', '2023-07-23 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-e418-409f-a181-10456400412f', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-23 13:00:00', '2023-07-23 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-e69c-4bd7-aea1-4fde20b66197', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-23 15:01:00', '2023-07-23 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-e8a2-4185-95ab-c2cd405cce93', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-24 08:00:00', '2023-07-24 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-ea1e-44e8-875e-aa5d7391ddea', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-24 10:01:00', '2023-07-24 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-eb8a-4e00-b3f9-ddad0192b2a0', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-24 13:00:00', '2023-07-24 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-ece8-4614-b9e8-f27353cd3a18', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-24 15:01:00', '2023-07-24 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-eedd-497b-86aa-1d715756f125', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-25 08:00:00', '2023-07-25 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-f031-49d8-bc12-84a46b52db96', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-25 10:01:00', '2023-07-25 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-f178-4a7e-8ea7-13154c32d84d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-25 13:00:00', '2023-07-25 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-f2e7-4516-91a4-7678d39a2d46', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-25 15:01:00', '2023-07-25 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-f57e-49f1-a4be-1144188d3f45', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-26 08:00:00', '2023-07-26 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-f808-420f-a58a-c000107bcf27', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-26 10:01:00', '2023-07-26 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-fa0f-498b-bf1c-233361a2fccb', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-26 13:00:00', '2023-07-26 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-fbe0-456c-a6bc-4f069fed4300', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-26 15:01:00', '2023-07-26 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1d-fe8a-4b1e-a8f8-d8d493f21589', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-27 08:00:00', '2023-07-27 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-0334-47d4-9391-55b799a73734', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-27 10:01:00', '2023-07-27 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-05d7-45dc-ac47-b1e638b42be7', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-27 13:00:00', '2023-07-27 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-07f9-4b6c-8141-37be50fd622b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-27 15:01:00', '2023-07-27 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-0ac1-4e51-bc03-35c24b157a89', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-28 08:00:00', '2023-07-28 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-0cd3-424b-9245-26b76a9c5306', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-28 10:01:00', '2023-07-28 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-0efa-40ee-8389-c4978a5a60f9', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-28 13:00:00', '2023-07-28 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-10d4-4d59-a6ff-351f7acde77b', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-28 15:01:00', '2023-07-28 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1320-426a-b276-58ab41666aaf', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-29 08:00:00', '2023-07-29 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-14a1-412a-b010-7021635fffaa', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-29 10:01:00', '2023-07-29 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-160a-48f4-b9fa-3edeff0491f8', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-29 13:00:00', '2023-07-29 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1751-4cf9-bff6-5e01fd59978d', '994cbf1c-bcd3-4878-9de4-4ab38b18c4ac', 'AVAILABLE', NULL, '2023-07-29 15:01:00', '2023-07-29 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1927-4c58-9e5a-f57b842db3df', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-05-31 08:00:00', '2023-05-31 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-19a3-470e-82d3-88f7b2e12fc7', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-05-31 10:01:00', '2023-05-31 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1a19-4cb4-9ed1-004cb6fc33e7', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-05-31 13:00:00', '2023-05-31 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1a8f-4012-b1a2-2d93beb8abb3', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-05-31 15:01:00', '2023-05-31 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1b93-4644-a811-e3251bbbf8c4', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-01 08:00:00', '2023-06-01 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1c12-43d0-928e-c2502cc840d0', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-01 10:01:00', '2023-06-01 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1c86-40af-a58e-6a7715a52563', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-01 13:00:00', '2023-06-01 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1cfb-47e4-873a-e13c731912c1', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-01 15:01:00', '2023-06-01 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1e05-40ae-8643-8b4992a3fe02', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-02 08:00:00', '2023-06-02 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1ea6-47dd-ba81-f1d9c71000cc', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-02 10:01:00', '2023-06-02 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-1f41-4f14-9c25-16fcede30d84', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-02 13:00:00', '2023-06-02 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2002-487b-b7a0-1cf70b9f4302', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-02 15:01:00', '2023-06-02 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-21a2-4a66-8cf3-a970b245b483', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-03 08:00:00', '2023-06-03 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2278-4284-82f3-c5450f313987', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-03 10:01:00', '2023-06-03 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2332-4986-b151-e18c155784f3', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-03 13:00:00', '2023-06-03 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-23ec-4699-873d-6a757cdb3b95', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-03 15:01:00', '2023-06-03 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-255d-468f-8025-1ae27a3b005b', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-04 08:00:00', '2023-06-04 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-263a-41d2-a14d-ca7506a9bcf5', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-04 10:01:00', '2023-06-04 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-26d6-49c6-9cac-70da6a4f53df', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-04 13:00:00', '2023-06-04 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2775-4654-a038-c11fea950193', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-04 15:01:00', '2023-06-04 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2873-4ae6-a7da-f41c69ffb0a8', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-05 08:00:00', '2023-06-05 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-290b-4aa6-9221-a9dac0dcb6d7', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-05 10:01:00', '2023-06-05 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-29b1-479b-93df-20abe6aa6394', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-05 13:00:00', '2023-06-05 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2a91-4680-92b8-b456fba8c854', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-05 15:01:00', '2023-06-05 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2c01-438c-b509-8bad1836291a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-06 08:00:00', '2023-06-06 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2cda-4646-a381-e527467c5aeb', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-06 10:01:00', '2023-06-06 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2dac-482c-8502-53c351fc76a2', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-06 13:00:00', '2023-06-06 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-2ebb-452a-a0b4-96e152954cea', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-06 15:01:00', '2023-06-06 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-305c-4c39-b75d-5c71d14cc2fb', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-07 08:00:00', '2023-06-07 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-315c-4a43-8d8d-8b6247063b73', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-07 10:01:00', '2023-06-07 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3236-4017-8a67-0c120178dc14', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-07 13:00:00', '2023-06-07 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3336-4971-ae30-660ddbcc2c10', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-07 15:01:00', '2023-06-07 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3593-405c-b6cd-11bfd860ea1d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-08 08:00:00', '2023-06-08 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3652-4938-91c1-e139806b5611', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-08 10:01:00', '2023-06-08 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3715-4ac3-a6cf-ff86beb6d341', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-08 13:00:00', '2023-06-08 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-37db-4919-825c-8da95192f254', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-08 15:01:00', '2023-06-08 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3932-4cda-9b60-83211826abb1', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-09 08:00:00', '2023-06-09 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-39fc-4116-aed2-f30119c5a0ad', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-09 10:01:00', '2023-06-09 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3ac5-4f15-ad4e-a9be1ad2d749', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-09 13:00:00', '2023-06-09 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3bcf-49d3-b8cd-7a301493e84f', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-09 15:01:00', '2023-06-09 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3e24-412f-9326-aaf09707f387', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-10 08:00:00', '2023-06-10 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-3f51-4de1-8b10-41391ced86c7', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-10 10:01:00', '2023-06-10 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4075-4c18-b8ba-fa4a3313a0b9', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-10 13:00:00', '2023-06-10 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-415b-4bf8-84ab-ad7cc60af03e', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-10 15:01:00', '2023-06-10 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-42b8-4258-b7dd-fd9bd9a59d54', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-11 08:00:00', '2023-06-11 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4362-455d-ab20-d60dc79ba090', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-11 10:01:00', '2023-06-11 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-440b-4281-8934-3072de24f09b', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-11 13:00:00', '2023-06-11 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-44b8-4d12-adf0-bc7f0a720f3f', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-11 15:01:00', '2023-06-11 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-45dd-4d9a-a7a8-5046d8f6de8c', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-12 08:00:00', '2023-06-12 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4681-461d-93d1-fc603b388e0c', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-12 10:01:00', '2023-06-12 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-471a-4a69-ba5b-9e6052929d93', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-12 13:00:00', '2023-06-12 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-47b6-44e2-aa5d-0d52f210910a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-12 15:01:00', '2023-06-12 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-48c0-4458-9f3c-44bc8857dbe3', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-13 08:00:00', '2023-06-13 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-49c9-4280-bf4f-2353166ed79b', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-13 10:01:00', '2023-06-13 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4a69-4f35-9f7e-efb47407d4f8', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-13 13:00:00', '2023-06-13 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4b08-4dd0-b64d-7a10ca11e272', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-13 15:01:00', '2023-06-13 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4c18-4bff-9030-28725be75486', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-14 08:00:00', '2023-06-14 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4cbd-4d7a-986e-45925cdd80a0', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-14 10:01:00', '2023-06-14 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4d5f-4cf4-988d-3d22bb8510d8', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-14 13:00:00', '2023-06-14 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4e03-4eb0-929f-a59f64b05641', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-14 15:01:00', '2023-06-14 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4f18-439e-ad46-35620921e61e', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-15 08:00:00', '2023-06-15 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-4fc1-49ac-8784-ee3e87f1dfbf', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-15 10:01:00', '2023-06-15 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-5069-494b-b01e-28787da95f3d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-15 13:00:00', '2023-06-15 15:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-5135-427f-8b9e-09b2a9e5e5a2', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-15 15:01:00', '2023-06-15 18:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-5286-4e0f-a814-06c78f5185ad', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-16 08:00:00', '2023-06-16 10:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-5343-434b-a939-51812efab660', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-16 10:01:00', '2023-06-16 12:00:00', '2023-05-31 16:03:49', '2023-05-31 16:03:49'),
('994cbf1e-540d-4d9a-8ce2-67ed34c143cb', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-16 13:00:00', '2023-06-16 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-54cb-493b-9de9-cab7330e59cc', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-16 15:01:00', '2023-06-16 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-55f7-4562-bb0d-806a0a685cca', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-17 08:00:00', '2023-06-17 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-56a6-4d74-8769-65bf6cf381bf', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-17 10:01:00', '2023-06-17 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5754-4d5c-b921-391b0a9f2f3e', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-17 13:00:00', '2023-06-17 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5805-41bd-b5c1-b5b9fdfa1194', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-17 15:01:00', '2023-06-17 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5936-45bc-b6f6-bde08430f51d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-18 08:00:00', '2023-06-18 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-59e6-4e98-b29f-a5369725fb1d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-18 10:01:00', '2023-06-18 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5a99-48d1-9e9d-375adc8724ab', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-18 13:00:00', '2023-06-18 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5b4e-48cd-8673-cf604b9fdd57', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-18 15:01:00', '2023-06-18 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5c7d-4609-bd9f-663b245e7f7a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-19 08:00:00', '2023-06-19 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5d3e-4639-8ff0-5cd599330760', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-19 10:01:00', '2023-06-19 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5dfa-4b9e-bd1d-3950ddee9394', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-19 13:00:00', '2023-06-19 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5eb1-4bcd-8387-fae9aba273f3', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-19 15:01:00', '2023-06-19 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-5fe2-40c1-8129-c3dd7fb0e102', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-20 08:00:00', '2023-06-20 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-609e-4478-addf-f5b5810f73b6', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-20 10:01:00', '2023-06-20 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-616b-4dda-9277-58341414e97c', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-20 13:00:00', '2023-06-20 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-623c-4208-aeee-86c22dbb5e27', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-20 15:01:00', '2023-06-20 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50');
INSERT INTO `studio_events` (`id`, `studio_id`, `status`, `hold_until`, `start_time`, `end_time`, `created_at`, `updated_at`) VALUES
('994cbf1e-63ba-4589-be55-26aec47cbd8e', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-21 08:00:00', '2023-06-21 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-64a5-489e-861e-a63427bb8a45', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-21 10:01:00', '2023-06-21 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-658e-4b80-a2fc-5741322a8136', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-21 13:00:00', '2023-06-21 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-6677-4823-9c03-3ac17a59c077', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-21 15:01:00', '2023-06-21 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-67f3-45d0-b7d9-4ca7933a67bc', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-22 08:00:00', '2023-06-22 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-68e0-4f3d-8751-470984bca5da', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-22 10:01:00', '2023-06-22 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-69cd-4cbc-bfda-a04f0ab5886d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-22 13:00:00', '2023-06-22 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-6ab9-44fe-86b3-8f1d242f0830', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-22 15:01:00', '2023-06-22 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-6c3f-4961-999c-0567eb957bc0', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-23 08:00:00', '2023-06-23 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-6d2a-41f8-a702-5d66453cfae8', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-23 10:01:00', '2023-06-23 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-6e07-4a0f-b679-a1d548f16af5', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-23 13:00:00', '2023-06-23 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-6eca-4ffa-bae5-4cb2121d4628', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-23 15:01:00', '2023-06-23 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-6ffb-41cd-b3cf-c8e03f9ff77f', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-24 08:00:00', '2023-06-24 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-70c0-4b73-aa76-a56277ae91e0', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-24 10:01:00', '2023-06-24 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-7185-4da7-9d51-db6a7fc76115', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-24 13:00:00', '2023-06-24 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-7249-4ad9-9df7-36e2ccd20e35', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-24 15:01:00', '2023-06-24 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-737d-48b6-8d6a-68c557be4ccb', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-25 08:00:00', '2023-06-25 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-744a-4e01-8528-18ecc09dda62', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-25 10:01:00', '2023-06-25 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-750f-4e5e-924e-203e6bd509f9', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-25 13:00:00', '2023-06-25 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-75d6-4632-a4b3-fb9bbed14800', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-25 15:01:00', '2023-06-25 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-7710-4633-a64f-7c5bba99b166', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-26 08:00:00', '2023-06-26 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-77e7-495a-90a8-947b6edcc628', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-26 10:01:00', '2023-06-26 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-78c9-4022-aae7-7d08ad15b17e', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-26 13:00:00', '2023-06-26 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-79d0-40a3-9d46-f4c8a1955604', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-26 15:01:00', '2023-06-26 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-7c26-4ed6-bc8c-3714206b989c', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-27 08:00:00', '2023-06-27 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-7d64-4623-8837-f18e8c0e40f5', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-27 10:01:00', '2023-06-27 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-7e6f-4bd5-afec-8db88918a419', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-27 13:00:00', '2023-06-27 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-7f7c-4e51-ad4d-e8613a128209', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-27 15:01:00', '2023-06-27 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-812a-4b83-a677-38aca5b0ff86', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-28 08:00:00', '2023-06-28 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-820f-44b2-92b0-81af8f06d824', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-28 10:01:00', '2023-06-28 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-82f2-4b8f-a784-c6cc348b745e', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-28 13:00:00', '2023-06-28 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8410-40a9-a043-2529ff4b0f0a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-28 15:01:00', '2023-06-28 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8631-4380-92d3-0d4beede2d2d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-29 08:00:00', '2023-06-29 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8756-4a4d-bbe8-58b546b42c12', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-29 10:01:00', '2023-06-29 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8882-4590-baf3-f4cb3f1ef96d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-29 13:00:00', '2023-06-29 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-898d-45bc-a849-6252ffc63cd2', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-29 15:01:00', '2023-06-29 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8b07-46cb-a064-383319daa996', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-30 08:00:00', '2023-06-30 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8bf6-429a-a040-4510ded31372', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-30 10:01:00', '2023-06-30 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8ce5-429e-a311-ebaedda86ca4', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-30 13:00:00', '2023-06-30 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8dc5-4c36-9d38-30d3ee304022', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-06-30 15:01:00', '2023-06-30 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8f0d-4d47-8f86-27863e530505', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-01 08:00:00', '2023-07-01 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-8fe6-4373-ade4-b9a8f3fe0d8c', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-01 10:01:00', '2023-07-01 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-90be-42ad-871e-86337bdc2485', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-01 13:00:00', '2023-07-01 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-919b-47b4-8f4c-be30544af100', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-01 15:01:00', '2023-07-01 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-92e1-4a30-a5fa-d1e1b739dd9a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-02 08:00:00', '2023-07-02 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-93ce-4480-82fe-697ebfeffac3', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-02 10:01:00', '2023-07-02 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-94a9-4c1f-a22b-6647456856d1', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-02 13:00:00', '2023-07-02 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-9584-4ed6-9885-df233f5ff48f', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-02 15:01:00', '2023-07-02 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-9710-463c-8820-af5d4eae0600', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-03 08:00:00', '2023-07-03 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-97eb-4e6d-9146-05c97cc99f11', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-03 10:01:00', '2023-07-03 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-98d3-4ae9-bb09-f00c3934abb5', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-03 13:00:00', '2023-07-03 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-99b4-4cdb-b076-98c97a589819', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-03 15:01:00', '2023-07-03 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-9b12-4993-bb26-2064f854ab7d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-04 08:00:00', '2023-07-04 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-9bf3-45bf-8408-5b319435bac1', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-04 10:01:00', '2023-07-04 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-9d13-4224-8723-16d8adde1fd2', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-04 13:00:00', '2023-07-04 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-9df5-49fa-a1bf-a2bc82b80a83', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-04 15:01:00', '2023-07-04 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-9f55-4610-a83a-2fc038225690', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-05 08:00:00', '2023-07-05 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a03b-496a-a858-8b9590a93505', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-05 10:01:00', '2023-07-05 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a122-4fc0-9587-2a6864996c6b', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-05 13:00:00', '2023-07-05 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a207-49c7-be52-749c9dd245fd', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-05 15:01:00', '2023-07-05 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a360-4384-8bcf-b71945a1f64d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-06 08:00:00', '2023-07-06 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a44c-4264-9de6-ac8029a0dbfe', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-06 10:01:00', '2023-07-06 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a534-4643-a347-f369362a1221', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-06 13:00:00', '2023-07-06 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a621-4373-a6bb-31b2a2df1b86', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-06 15:01:00', '2023-07-06 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a77d-4da0-93c5-6705212e0239', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-07 08:00:00', '2023-07-07 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a869-4d98-95f1-fd8d6661c59f', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-07 10:01:00', '2023-07-07 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-a956-4042-b4e4-4b6544d79ddc', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-07 13:00:00', '2023-07-07 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-aa42-49be-b615-9f863c804e3d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-07 15:01:00', '2023-07-07 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-aba4-4d26-bcab-46fe544be5a9', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-08 08:00:00', '2023-07-08 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-ac93-4b63-bd16-2dea2539831f', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-08 10:01:00', '2023-07-08 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-ad83-4e60-ab12-e2fb99b5d375', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-08 13:00:00', '2023-07-08 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-ae75-459e-a74c-38b4e4af76f5', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-08 15:01:00', '2023-07-08 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-aff3-4ea3-ae6c-9688b679052a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-09 08:00:00', '2023-07-09 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-b0ec-42a8-9bf8-2871e372a066', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-09 10:01:00', '2023-07-09 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-b1e4-48cf-9158-d5a4b7df0475', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-09 13:00:00', '2023-07-09 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-b2db-42bc-b878-eb1cec9121f1', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-09 15:01:00', '2023-07-09 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-b448-4bc9-8c24-72b03527968b', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-10 08:00:00', '2023-07-10 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-b549-4b61-8379-51f94b273370', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-10 10:01:00', '2023-07-10 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-b645-4973-aca5-eb4b2965a1d5', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-10 13:00:00', '2023-07-10 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-b7ba-4709-adc3-931e9563faac', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-10 15:01:00', '2023-07-10 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-b943-42f5-acf9-cd5ffd31ada4', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-11 08:00:00', '2023-07-11 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-ba59-418d-a6ff-04a61d1dc714', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-11 10:01:00', '2023-07-11 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-bb7c-455e-aae6-a50dade60ff4', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-11 13:00:00', '2023-07-11 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-bc9b-4159-aa8e-b97f06ba2902', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-11 15:01:00', '2023-07-11 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-be20-4040-8948-140eb201a756', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-12 08:00:00', '2023-07-12 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-bf2b-448f-98ec-092efd100516', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-12 10:01:00', '2023-07-12 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-c037-432e-ac22-7eef3f9d2d0d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-12 13:00:00', '2023-07-12 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-c13f-4fd0-af3d-5314371e2fc0', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-12 15:01:00', '2023-07-12 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-c2c6-4d5b-b004-28956d146fed', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-13 08:00:00', '2023-07-13 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-c3d9-4c5c-bb5a-0a5c2d8b2249', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-13 10:01:00', '2023-07-13 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-c4e7-4904-a88e-a7a71eef00f9', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-13 13:00:00', '2023-07-13 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-c614-4739-8f23-cfc47d7da228', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-13 15:01:00', '2023-07-13 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-c7c5-41d3-b8ac-bd7ff52697ba', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-14 08:00:00', '2023-07-14 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-c8ce-4cda-9788-a48f9ca4ed1a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-14 10:01:00', '2023-07-14 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-c9d5-4a77-8392-abee269689e0', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-14 13:00:00', '2023-07-14 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-cadc-48ba-bf49-13d7f775659c', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-14 15:01:00', '2023-07-14 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-cc57-44ad-860d-c691f89eeddc', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-15 08:00:00', '2023-07-15 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-cd65-4e12-813e-99f89c226a19', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-15 10:01:00', '2023-07-15 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-ce72-46d1-b0b6-da8581d88806', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-15 13:00:00', '2023-07-15 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-cf80-4323-992b-f66c1d4aec53', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-15 15:01:00', '2023-07-15 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-d10d-4b97-ac2d-f5a41c3647ed', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-16 08:00:00', '2023-07-16 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-d27f-4953-b5f6-5b7efd461f36', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-16 10:01:00', '2023-07-16 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-d436-4c8f-98f9-43bb047f19ef', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-16 13:00:00', '2023-07-16 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-d56b-427f-aa2e-15a1f2da4e0a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-16 15:01:00', '2023-07-16 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-d772-45fe-839c-d83fddf11350', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-17 08:00:00', '2023-07-17 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-d8ad-426a-8094-c361fd5f51fc', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-17 10:01:00', '2023-07-17 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-d9e3-4eaf-be77-2ae3af2e19c9', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-17 13:00:00', '2023-07-17 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-db1b-4f3d-a785-bfc7716d7c27', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-17 15:01:00', '2023-07-17 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-dcde-4c9a-9ee5-9310ec4695d2', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-18 08:00:00', '2023-07-18 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-de1e-4cc6-98ed-0554cfd37ad0', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-18 10:01:00', '2023-07-18 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-df58-451d-82ff-167d27614403', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-18 13:00:00', '2023-07-18 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-e091-4d2c-a27e-8ea01b3d0821', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-18 15:01:00', '2023-07-18 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-e253-4665-9334-d2147e898e7e', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-19 08:00:00', '2023-07-19 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-e38d-406d-a196-6976a2a6c6a7', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-19 10:01:00', '2023-07-19 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-e4bb-4b45-ad0c-97b61deb4a55', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-19 13:00:00', '2023-07-19 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-e5e5-4c1c-8490-9f125f654b05', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-19 15:01:00', '2023-07-19 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-e78c-4cc7-8bb5-7884291dabb7', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-20 08:00:00', '2023-07-20 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-e8b8-4230-91e2-b7d515905599', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-20 10:01:00', '2023-07-20 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-e9e6-4d46-9a5e-220fa25687fb', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-20 13:00:00', '2023-07-20 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-eb18-40d7-9a73-dfd66a627095', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-20 15:01:00', '2023-07-20 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-ecde-47c3-8f9b-b1d50b0d90e1', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-21 08:00:00', '2023-07-21 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-ee76-47f5-b0f8-78c5688161c0', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-21 10:01:00', '2023-07-21 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-f06a-4749-be23-3cd2d2537cd1', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-21 13:00:00', '2023-07-21 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-f231-4801-a51d-0e62fe9ca973', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-21 15:01:00', '2023-07-21 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-f405-437a-8f3d-234a08e67376', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-22 08:00:00', '2023-07-22 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-f55d-4660-bb51-8e4320892af4', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-22 10:01:00', '2023-07-22 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-f6b3-4593-9920-e04c5c4004b6', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-22 13:00:00', '2023-07-22 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-f80c-4b4e-bcc9-6b0afabe27c0', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-22 15:01:00', '2023-07-22 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-fa08-4cf9-a095-4c576f07fda9', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-23 08:00:00', '2023-07-23 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-fb63-4034-9f75-7e9fe7761b8f', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-23 10:01:00', '2023-07-23 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-fcad-4de2-b9db-44859577054d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-23 13:00:00', '2023-07-23 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-fe0b-470a-b132-f32a84eeabcf', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-23 15:01:00', '2023-07-23 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1e-ffe5-49fa-9df7-fc357f3a9105', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-24 08:00:00', '2023-07-24 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-0129-4acb-82cc-7956b7e858fc', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-24 10:01:00', '2023-07-24 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-0269-40ae-9c11-6e41db411c41', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-24 13:00:00', '2023-07-24 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-03b2-4c08-b0da-9c6ea01bc120', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-24 15:01:00', '2023-07-24 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-05b0-4ef5-8e3f-40ab8aa09159', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-25 08:00:00', '2023-07-25 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-071f-4c8e-9d63-6b6dfedf3089', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-25 10:01:00', '2023-07-25 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-0858-44e6-855a-a51b8dd81225', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-25 13:00:00', '2023-07-25 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-0995-455a-b38d-cd9bb6c437a3', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-25 15:01:00', '2023-07-25 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-0b4b-415a-b725-cd766f2e586a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-26 08:00:00', '2023-07-26 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-0c88-4c9b-9aff-5f03fe35760d', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-26 10:01:00', '2023-07-26 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-0dc9-4379-88f4-93d9672e95e7', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-26 13:00:00', '2023-07-26 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-0f14-4d27-8f03-3e5bce2ae604', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-26 15:01:00', '2023-07-26 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-113e-45b0-90ab-91d3e3916c58', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-27 08:00:00', '2023-07-27 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-12a7-43f0-bee7-74645dd18da5', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-27 10:01:00', '2023-07-27 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-13ef-4b47-a269-8b6d2d70427b', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-27 13:00:00', '2023-07-27 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-1601-4caa-9263-85344a519027', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-27 15:01:00', '2023-07-27 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-18e2-42ae-9a76-673f0081f028', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-28 08:00:00', '2023-07-28 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-1a62-4315-a949-e7b39de7e680', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-28 10:01:00', '2023-07-28 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-1bef-4e56-bc46-8c29c37c5dce', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-28 13:00:00', '2023-07-28 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-1d7e-4c42-85b3-009741722ff6', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-28 15:01:00', '2023-07-28 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-1fa3-4b3a-a56e-06111833f54a', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-29 08:00:00', '2023-07-29 10:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-210d-45c5-9343-833cff487a7f', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-29 10:01:00', '2023-07-29 12:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-2272-4789-828c-59daf47b5295', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-29 13:00:00', '2023-07-29 15:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-23cc-414a-aff5-ca3c94216205', '994cbf1e-1792-4dac-b40d-d163f99d76b9', 'AVAILABLE', NULL, '2023-07-29 15:01:00', '2023-07-29 18:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-26ca-4dcc-a4f1-b85f823a9cc2', '994cbf1f-2647-4340-a04e-74fbeb797682', 'AVAILABLE', NULL, '2023-06-01 00:00:00', '2023-06-01 09:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50'),
('994cbf1f-288b-44fb-a39e-72266c345b40', '994cbf1f-27ef-4133-a8bc-57e0160cbae2', 'AVAILABLE', NULL, '2023-06-01 00:00:00', '2023-06-01 09:00:00', '2023-05-31 16:03:50', '2023-05-31 16:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `studio_log`
--

CREATE TABLE `studio_log` (
  `id` char(36) NOT NULL,
  `studio_id` char(36) NOT NULL,
  `status` enum('AVAILABLE','ON HOLD','BOOKED','EXPAIRED','CLOSED') NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` char(36) NOT NULL,
  `category_id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
('05b6fb88-3fad-4d44-aa33-e2b6c477adec', '66a235d8-f0a7-4ed5-9218-0367bd17f214', 'web', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('15de4f72-8e6f-4ed2-bb21-37140ab1e777', '1165a9da-1fc2-4dd5-ba2e-363a6e63455e', 'video editing', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('5820c9c8-c246-4ec3-9ed0-987fd6796dbe', '66a235d8-f0a7-4ed5-9218-0367bd17f214', 'blogposts', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('8c7665fb-5257-4b5e-9bb9-dd1d69eb50c9', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'studio tests', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('92b3e2d7-71aa-402e-8aca-7e032e498123', '2a50571d-9c5f-4f8d-b119-9fcf46c55837', 'android development', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('9592de16-ebc5-4c5c-b36b-5a10e9082ae3', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'sports', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('c687640f-0ce1-4c53-82c1-75189991c679', 'a5735b5d-c916-47ba-92ef-48a4c7bc2626', 'poster design', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('ca14c47c-047e-4d63-ad9b-81fbd4d3f3b3', '1165a9da-1fc2-4dd5-ba2e-363a6e63455e', '3d making', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('e7ef34ab-8ef7-4b1a-b1c1-8e08a8155e80', 'a5735b5d-c916-47ba-92ef-48a4c7bc2626', 'banner design', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('f14d2089-2479-414e-8aae-41e243ce8c5f', '2a50571d-9c5f-4f8d-b119-9fcf46c55837', 'machine learning development', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('fa0759b1-6443-47a5-a6a0-d9ff5cb8d1d5', '44c86847-0bff-4376-b1a9-5ad1e10d1ea7', 'wedding', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL),
('ffb0f2ec-965f-443b-aecd-e6ead7512c07', '2a50571d-9c5f-4f8d-b119-9fcf46c55837', 'web development', '2023-05-31 16:03:41', '2023-05-31 16:03:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` char(36) NOT NULL,
  `jwtv` varchar(64) NOT NULL,
  `verification_code` varchar(64) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `phone`, `email_verified_at`, `password`, `role_id`, `jwtv`, `verification_code`, `deleted_at`, `created_at`, `updated_at`) VALUES
('994cbef6-0212-4dfe-ab8f-89f6e061a1ee', 'test user2', 'test-user2@Hktia', 'testing2@gmail.com', NULL, NULL, '$2y$10$w9iKLjTx9A19OMc2SVY7euJPq3tug3cnCXXocjhdr4LlyHxQeKK1m', '13afb267-a38f-4188-96e4-53387d4c8cdc', 'QfUd8yh59P0V2aI96hGS3AfCj6hmwsgEnTYDTRG4Q986zF14562bgAJOE0yRsDte', NULL, NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef6-1dee-4b43-8cf1-0e4ad6c3f879', 'test user3', 'test-user3@2P0Xh', 'testing3@gmail.com', NULL, NULL, '$2y$10$RTZ9Gd2.mqBchHrdq/JeTOIw1SDpRFJFXHnlrRwd6e7XhpzSdywc2', '13afb267-a38f-4188-96e4-53387d4c8cdc', 'byHT6b09g4DniHpH3uofP5aqEMc9eRjZwBM8glzCxYr4JTPVz3G5mwlkJinOkBSH', NULL, NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef6-395b-461b-88fd-efcaff3b1f9a', 'test user4', 'test-user4@mwuaK', 'testing4@gmail.com', NULL, NULL, '$2y$10$k750l./Yp.XZIu5uGewLeebjQKqGa.wDpqWkgnRe5EhvgaFN7gu3e', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'Rc98DIvc20FZM6SyxSjAtYEaW0hZw4DKxArywHNIXHrR6YP624pdEJgW4OW9dcSh', NULL, NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef6-5372-4944-821b-be318146e480', 'test user5', 'test-user5@FeQS9', 'testing5@gmail.com', NULL, NULL, '$2y$10$lHyp/DWRKQrHw3ARj1gK3uPxJrWVOFcImP9.UHmkKJo402yGI2N0m', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'rpIVVYLqxUlbBctQ1jbbLOJ465P98OdQvGkTgIOn5HQPBY4F0tyPzC2HZuZjTRIk', NULL, NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef6-6d4c-438b-bf9f-c8fdb8213679', 'test user6', 'test-user6@8AqHV', 'testing6@gmail.com', NULL, NULL, '$2y$10$cCk9as8SFkmKld6iMnYnwOCtstfOgngjbXWtlwyogFBJPB612/ZMG', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'YXQrooDL2YhtM8SuPJnALc8eXwnrI3vIhScpBuiuIR0fKBGzhRzvTbdPNd2iGBYG', NULL, NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef6-88c7-4e02-865b-c24627bc789f', 'test user7', 'test-user7@zkWco', 'testing7@gmail.com', NULL, NULL, '$2y$10$Bb3nKPadeJ8hBUU.gOOi8OMGI44s9qSVaJC8zSMpd4WqChEX42xAG', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'UYJlPuS5RNMwE86f58SHf717aWkZMm7A1hVXMi4DknpeI4UdsEpna6IrJM9lkKdU', NULL, NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef6-a472-4602-9ebe-b5139eeb6094', 'test user8', 'test-user8@t8YmM', 'testing8@gmail.com', NULL, NULL, '$2y$10$tvcUx2efUzTFoN8rv7JTLePNVgZjGcyGPZOjR6dse91ZYm2Pb4UJG', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', '7yUrmh34Aha9SDj797GowkPWYrLtpeTU9ni47FUieu8LsnnVLcjW6kYdyKeM2BQc', NULL, NULL, '2023-05-31 16:03:23', '2023-05-31 16:03:23'),
('994cbef6-bff5-479f-a695-0efbe35251c6', 'test user1', 'test-user1@exst1', 'testing11@gmail.com', NULL, '2023-05-31 16:03:24', '$2y$10$H.QkWlXU5QLW1qi3tye5OuVlxJkP77P2cDQ1IVTU7XIOu6FtUQUey', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'kWOnYJ9My4oQkAaM2wQUc7QvUHpVU0QsayXG11bGa4XlnkcoTOjlj13UiYmN1FTd', NULL, NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef6-dbfa-4c64-92ac-645e3ba775e1', 'test user2', 'test-user2@N4ee6', 'testing12@gmail.com', NULL, '2023-05-31 16:03:24', '$2y$10$Z..FS/6GZQivQrwg/4..5uqxcMBzlECWyNs7jDWJz0FzF1pKHAMOq', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'C4gNEuYi61UKum3ksykJZUG7yLD2S0zgIhmnwG2E83N8alXg31LnWu1zODvNOfNm', NULL, NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef6-f795-4f3c-85b3-21c257867049', 'test user3', 'test-user3@6VQ8e', 'testing13@gmail.com', NULL, '2023-05-31 16:03:24', '$2y$10$6u.X.zP0MHL54j/k1humSOS9hP9nfC1I8WJYXNwl1P4md0PwJnIX.', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'aFZFxl8EBsH4XZmldR7nhTaMDmUG8urr7G4xvh6Tir4rtBkRSJYYe9U5YD2cnt6W', NULL, NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-1344-463c-a9f2-b10f438fab9a', 'test user4', 'test-user4@vFaDZ', 'testing14@gmail.com', NULL, '2023-05-31 16:03:24', '$2y$10$1HeNPDgCbD4YWlWCId/AceS/V1eJx36wu/h9bsXyjPOXyidzIavBW', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'CGCAOpJnqGeeVVZsV9n1wMNKo6S8fc3I6Pu9zB5MnYWLf6cqycCgxqH2W16rIhTN', NULL, NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-327c-48a9-be42-6e07b4733815', 'freelancer101', 'freelancer101@N6gF5', 'testing101@gmail.com', NULL, '2023-05-31 16:03:24', '$2y$10$HMQygWwCkQWLRfGer1T/OOnjQrLi5RtwtHYA15ZUtZm2ze5Hk5zl6', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'QbtW9Qpc3Zc4Na9SQAXzDX8QRv9XI1QIcs18xnjZqVNfEkQwb5kDbpee0vEgyifK', NULL, NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-5488-43f6-b184-f933a6a796f8', 'freelancer102', 'freelancer102@xlLUs', 'testing102@gmail.com', NULL, '2023-05-31 16:03:24', '$2y$10$Xm7fTwXmAeRRa8zKtOLesuPuXEpbtSfGBGHzWZHmsuzhXwYlKt75W', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'mYCkxzO5G7y4vACrXGfhGEvnDN0pzghRa7c4VvXHcsXaAZ66xGq42mvoddr7FWnW', NULL, NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-7618-43b1-b421-1f63392aaffb', 'freelancer103', 'freelancer103@uxl60', 'testing103@gmail.com', NULL, '2023-05-31 16:03:24', '$2y$10$YYqp1LQrNTeKEj9jMTL3QONcIGWfFjcEXWSOHjzs84vtA0U9uH7U.', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', '59VJ0PSG7j7AhWxZrXNJIz4QjU6FLiPGqLUFzeYOgZF7NFcytu8hAVFj6dRTRI7X', NULL, NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-98e3-452c-b989-aa38524fbb2b', 'freelancer104', 'freelancer104@z4wqt', 'testing104@gmail.com', NULL, '2023-05-31 16:03:24', '$2y$10$XpzJggX1i86gd.XcOUIqm.oVDL6oMkNVUje1sKbyA7kFxh.EFjZZy', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'WIOmVbHA86eLnnh6qX1u509fEUuIejZNzEuCcukyp4JB1VZHmKSHeGybPxn3KCMv', NULL, NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24'),
('994cbef7-bb8a-4a20-a6af-e28d782e17c8', 'freelancer105', 'freelancer105@S0Cju', 'testing105@gmail.com', NULL, '2023-05-31 16:03:24', '$2y$10$bLF7cQbjku9cHBac1kRuJOjjKsNP9zLkvhqAP8oS.n93/5sd7q1oe', '1f7bbac4-1685-4c7a-bfb4-70f8118052d8', 'W1Dsf2PoThmF21XNHDjFKq7FKVQPVIwQ0JX7GOZbJZ3lafGtZdN2NdNTOvIeySqU', NULL, NULL, '2023-05-31 16:03:24', '2023-05-31 16:03:24');

-- --------------------------------------------------------

--
-- Table structure for table `view_gigs_histories`
--

CREATE TABLE `view_gigs_histories` (
  `id` char(36) NOT NULL,
  `gig_id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `view_gigs_histories`
--

INSERT INTO `view_gigs_histories` (`id`, `gig_id`, `user_id`, `created_at`, `updated_at`) VALUES
('9952f295-8263-4f3f-bcc8-a30e719fac1c', 'a344db0a-857a-4ac9-994b-cfb462197b2b', '994cbef7-327c-48a9-be42-6e07b4733815', '2023-06-03 18:02:42', '2023-06-03 18:02:42');

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` char(36) NOT NULL,
  `user_id` char(36) NOT NULL,
  `gig_id` char(36) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `banners_banner_category_id_index` (`banner_category_id`);

--
-- Indexes for table `banner_categories`
--
ALTER TABLE `banner_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `banner_categories_name_unique` (`name`);

--
-- Indexes for table `base_studio_schedules`
--
ALTER TABLE `base_studio_schedules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `base_studio_schedules_studio_id_unique` (`studio_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_name_unique` (`name`);

--
-- Indexes for table `device_tokens`
--
ALTER TABLE `device_tokens`
  ADD UNIQUE KEY `device_tokens_token_unique` (`token`),
  ADD KEY `device_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `email_subscriptions`
--
ALTER TABLE `email_subscriptions`
  ADD UNIQUE KEY `email_subscriptions_email_unique` (`email`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `freelancers`
--
ALTER TABLE `freelancers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `freelancers_user_id_unique` (`user_id`);

--
-- Indexes for table `gigs`
--
ALTER TABLE `gigs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `gigs_slug_unique` (`slug`),
  ADD KEY `gigs_user_id_index` (`user_id`),
  ADD KEY `gigs_category_id_index` (`category_id`),
  ADD KEY `gigs_subcategory_id_index` (`subcategory_id`);

--
-- Indexes for table `gig_images`
--
ALTER TABLE `gig_images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `gig_images_image_unique` (`image`),
  ADD KEY `gig_images_gig_id_index` (`gig_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notification_category_id_foreign` (`notification_category_id`);

--
-- Indexes for table `notification_categories`
--
ALTER TABLE `notification_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `notification_categories_title_unique` (`title`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `otps_user_id_foreign` (`user_id`),
  ADD KEY `otps_otp_index` (`otp`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissionables`
--
ALTER TABLE `permissionables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permissionables_permission_id_index` (`permission_id`),
  ADD KEY `permissionables_permissionable_id_index` (`permissionable_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`),
  ADD KEY `permission_role_permission_id_foreign` (`permission_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ratings_user_id_gig_id_unique` (`user_id`,`gig_id`),
  ADD KEY `ratings_user_id_index` (`user_id`),
  ADD KEY `ratings_gig_id_index` (`gig_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_title_unique` (`title`);

--
-- Indexes for table `search_histories`
--
ALTER TABLE `search_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `search_histories_user_id_index` (`user_id`);

--
-- Indexes for table `studios`
--
ALTER TABLE `studios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `studios_gig_id_index` (`gig_id`);

--
-- Indexes for table `studio_events`
--
ALTER TABLE `studio_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `studio_events_studio_id_index` (`studio_id`);

--
-- Indexes for table `studio_log`
--
ALTER TABLE `studio_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `studio_log_studio_id_index` (`studio_id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subcategories_name_unique` (`name`),
  ADD KEY `subcategories_category_id_index` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- Indexes for table `view_gigs_histories`
--
ALTER TABLE `view_gigs_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `view_gigs_histories_gig_id_index` (`gig_id`),
  ADD KEY `view_gigs_histories_user_id_index` (`user_id`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `wishlists_user_id_gig_id_unique` (`user_id`,`gig_id`),
  ADD KEY `wishlists_user_id_index` (`user_id`),
  ADD KEY `wishlists_gig_id_index` (`gig_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `permissionables`
--
ALTER TABLE `permissionables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `permission_role`
--
ALTER TABLE `permission_role`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `banners`
--
ALTER TABLE `banners`
  ADD CONSTRAINT `banners_banner_category_id_foreign` FOREIGN KEY (`banner_category_id`) REFERENCES `banner_categories` (`id`);

--
-- Constraints for table `base_studio_schedules`
--
ALTER TABLE `base_studio_schedules`
  ADD CONSTRAINT `base_studio_schedules_studio_id_foreign` FOREIGN KEY (`studio_id`) REFERENCES `studios` (`id`);

--
-- Constraints for table `device_tokens`
--
ALTER TABLE `device_tokens`
  ADD CONSTRAINT `device_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `freelancers`
--
ALTER TABLE `freelancers`
  ADD CONSTRAINT `freelancers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `gigs`
--
ALTER TABLE `gigs`
  ADD CONSTRAINT `gigs_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `gigs_subcategory_id_foreign` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`),
  ADD CONSTRAINT `gigs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_notification_category_id_foreign` FOREIGN KEY (`notification_category_id`) REFERENCES `notification_categories` (`id`) ON DELETE NO ACTION;

--
-- Constraints for table `otps`
--
ALTER TABLE `otps`
  ADD CONSTRAINT `otps_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `permissionables`
--
ALTER TABLE `permissionables`
  ADD CONSTRAINT `permissionables_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`);

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_gig_id_foreign` FOREIGN KEY (`gig_id`) REFERENCES `gigs` (`id`),
  ADD CONSTRAINT `ratings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `search_histories`
--
ALTER TABLE `search_histories`
  ADD CONSTRAINT `search_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `studios`
--
ALTER TABLE `studios`
  ADD CONSTRAINT `studios_gig_id_foreign` FOREIGN KEY (`gig_id`) REFERENCES `gigs` (`id`);

--
-- Constraints for table `studio_events`
--
ALTER TABLE `studio_events`
  ADD CONSTRAINT `studio_events_studio_id_foreign` FOREIGN KEY (`studio_id`) REFERENCES `studios` (`id`);

--
-- Constraints for table `studio_log`
--
ALTER TABLE `studio_log`
  ADD CONSTRAINT `studio_log_studio_id_foreign` FOREIGN KEY (`studio_id`) REFERENCES `studios` (`id`);

--
-- Constraints for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `subcategories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION;

--
-- Constraints for table `view_gigs_histories`
--
ALTER TABLE `view_gigs_histories`
  ADD CONSTRAINT `view_gigs_histories_gig_id_foreign` FOREIGN KEY (`gig_id`) REFERENCES `gigs` (`id`),
  ADD CONSTRAINT `view_gigs_histories_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_gig_id_foreign` FOREIGN KEY (`gig_id`) REFERENCES `gigs` (`id`),
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
